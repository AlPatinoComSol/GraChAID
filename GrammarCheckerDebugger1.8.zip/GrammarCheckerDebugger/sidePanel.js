import Typo from 'typo-js';
import { GoogleGenerativeAI } from "@google/generative-ai";

var dictionary = new Typo("en_US", false, false, { dictionaryPath: "/node_modules/typo-js/dictionaries" });

const PREFERED_MODEL = process.env.PREFERED_MODEL;
// Initialize Gemini with the API key
var genAI = null;
var model = null;


try{
    const instructions = localStorage.getItem('systemInstructions');
    console.log('Loaded Instructions:', instructions);
    genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

    model = genAI.getGenerativeModel({
        model: "gemini-1.5-flash",
        systemInstruction: instructions
        });
}catch(error){
    genAI = null;
    model = null;
}

function getReadableErrorMessage(errorType, error) {
    const errorMessages = {
        error_word_mistakes: {
            title: "Word Usage Error",
            description: word => `The word "${word}" might be inappropriate or incorrect in this context.`
        },
        error_no_ends_with_dot: {
            title: "Missing Period",
            description: "The thought should end with a period (.)"
        },
        error_edit_numbers_not_in_thought: {
            title: "Missing Line Numbers",
            description: "The edit line numbers should be mentioned in the thought."
        },
        error_unmatched_backticks: {
            title: "Unmatched Code Markers",
            description: "There are unmatched backticks (`) in the text. Code snippets should be wrapped in pairs of backticks."
        },
        error_uppercase_no_backticks: {
            title: "Unmarked Code (Uppercase)",
            description: word => `The uppercase term "${word}" should be wrapped in backticks.`
        },
        error_common_word_no_backticks: {
            title: "Unmarked Technical Term",
            description: word => `The technical term "${word}" should be wrapped in backticks.`
        },
        error_snakecase_no_backticks: {
            title: "Unmarked Code (Snake Case)",
            description: word => `The snake_case term "${word}" should be wrapped in backticks.`
        },
        error_path_no_backticks: {
            title: "Unmarked File Path",
            description: path => `The file path "${path}" should be wrapped in backticks.`
        },
        error_spell_checker: {
            title: "Possible Spelling Error",
            description: (word, suggestion) => `"${word}" might be misspelled${suggestion ? `. Did you mean "${suggestion}"?` : '.'}`
        },
        error_not_submit_action: {
            title: "Incomplete Submit Action",
            description: "The submit action was not completed successfully."
        },
        error_consecutive_spaces: {
            title: "Consecutive Spaces",
            description: "The thought contains consecutive spaces."
        }
    };

    return errorMessages[errorType] || { 
        title: "Unknown Error",
        description: "An unspecified error occurred."
    };
}

async function analyzeWithGemini(turn) {
    try {
        const chatSession = model.startChat({
            generationConfig: {
                temperature: 1,
                topP: 0.95,
                topK: 40,
                maxOutputTokens: 8192,
            },
        });

        const prompt = JSON.stringify({
            thought: turn.thought,
            action: turn.action
        });
        
        //console.log(prompt);

        const result = await chatSession.sendMessage(prompt);
        try {
            const analysis = JSON.parse(result.response.candidates[0].content.parts[0].text.replace(/```json\n/, '').replace(/\n```/, ''));    
            //console.log(analysis);
            return analysis;
        } catch (error) {
            console.error('Error analyzing with Gemini:', error);
            return null;
        }
    } catch (error) {
        console.error('Error analyzing with Gemini:', error);
        return null;
    }
}

// Function to add a turn to the sidebar
function addTurn(turnNumber, turn, analysisResults) {
    const errorList = document.getElementById('errorList');
    
    // Create a list item for the turn
    const listItem = document.createElement('li');
    listItem.id = turn.ID; // Add the ID to the list item
    var geminiAnalysis = null;
    try{
        geminiAnalysis = analysisResults.geminiAnalysis;
    }catch(error){analysisResults
        geminiAnalysis = null
    }
    
    // Set background color based on the presence of errors
    if (Object.keys(analysisResults.analysis.errors).length > 0 || (geminiAnalysis && geminiAnalysis.severity > 0)) { 
        listItem.style.backgroundColor = 'rgba(255, 0, 0, 0.3)';
    } else {
        listItem.style.backgroundColor = 'rgba(0, 255, 0, 0.3)';
    }

    // Create a container for the header content (turn info and button)
    const headerContainer = document.createElement('div');
    headerContainer.className = 'turn-header';

    // Create a div to hold the visible content
    const visibleContent = document.createElement('div');
    visibleContent.innerHTML = `<strong>#</strong> ${turnNumber} - <strong>ID:</strong> <a href="#" class="id-link">${turn.ID}</a>`;

    // Add click handler for the ID link
    const idLink = visibleContent.querySelector('.id-link');
    idLink.onclick = function(e) {
        e.preventDefault();
        e.stopPropagation();
        // Send message to content script to scroll to this ID
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'scrollToElement',
                elementId: turn.ID
            });
        });
    };

    // Create toggle button
    const toggleButton = document.createElement('button');
    toggleButton.className = 'toggle-button';
    toggleButton.innerHTML = '<i class="fas fa-chevron-down"></i>';

    // Create copy button
    const copyButton = document.createElement('button');
    copyButton.className = 'copy-button';
    copyButton.innerHTML = '<i class="fas fa-copy"></i>';
    copyButton.style.display = 'none'; // Initially hidden
    
    // Create button container
    const buttonContainer = document.createElement('div');
    buttonContainer.className = 'button-container';
    buttonContainer.appendChild(copyButton);
    buttonContainer.appendChild(toggleButton);

    // Add visible content and buttons to header container
    headerContainer.appendChild(visibleContent);
    headerContainer.appendChild(buttonContainer);

    // Create a div to hold the errors (initially hidden)
    const errorContent = document.createElement('div');
    errorContent.className = 'error-content';
    errorContent.style.display = 'none';

    // Build error messages line by line with better formatting
    let errorMessages = [];
    for (const errorType in analysisResults.analysis.errors) {
        const errorValue = analysisResults.analysis.errors[errorType];
        const errorInfo = getReadableErrorMessage(errorType);
        
        if (Array.isArray(errorValue)) {
            if (errorType === 'error_spell_checker') {
                errorValue.forEach(errorObj => {
                    errorMessages.push(`
                        <div class="error-item">
                            <div class="error-title">${errorInfo.title}</div>
                            <div class="error-description">
                                ${errorInfo.description(errorObj.error, errorObj.correction_candidate)}
                            </div>
                        </div>
                    `);
                });
            } else {
                errorValue.forEach(error => {
                    errorMessages.push(`
                        <div class="error-item">
                            <div class="error-title">${errorInfo.title}</div>
                            <div class="error-description">
                                ${errorInfo.description(error)}
                            </div>
                        </div>
                    `);
                });
            }
        } else {
            errorMessages.push(`
                <div class="error-item">
                    <div class="error-title">${errorInfo.title}</div>
                    <div class="error-description">
                        ${errorInfo.description}
                    </div>
                </div>
            `);
        }
    }
    
    //console.log(geminiAnalysis);   
    // Add Gemini analysis if available
    if (geminiAnalysis) {
        console.log(geminiAnalysis);
        if (geminiAnalysis.severity > 0) {
            if (geminiAnalysis.failNotes && Array.isArray(geminiAnalysis.failNotes) && geminiAnalysis.failNotes.length > 0) {
                errorMessages.push(`
                    <div class="error-item gemini-error">
                        <div class="error-title">Turn Analysis</div>
                        <div class="error-description">
                            <div class="fail-notes">
                                ${geminiAnalysis.failNotes.map(note => `
                                    <div class="fail-note">
                                        <div class="note-comment">${note.comments}</div>
                                        <div class="note-suggestion">${note.suggested_correction || ''}</div>
                                    </div>
                                `).join('')}
                            </div>
                            ${geminiAnalysis.suggestedThought ? `
                                <div class="suggested-thought-header">
                                    <strong>Suggested Thought:</strong>
                                </div>
                                <div class="suggestion-text" style="display: inline;">
                                    ${geminiAnalysis.suggestedThought}
                                </div>
                            ` : ''}
                        </div>
                    </div>
                `);
            }
        } else {
            // Add only the suggested thought
            errorMessages.push(`
                <div class="error-item gemini-error">
                    <div class="error-title">Turn Analysis</div>
                    <div class="error-description">
                        ${geminiAnalysis.suggestedThought ? `
                            <div class="suggested-thought-header">
                                <strong>Suggested Thought:</strong>
                            </div>
                            <div class="suggestion-text" style="display: inline;">
                                ${geminiAnalysis.suggestedThought}
                            </div>
                        ` : ''}
                    </div>
                </div>
            `);
        }
    }

    errorContent.innerHTML = `
        <strong>Turn Text:</strong>
        <div class="turn-text">
            <div class="text-content">
                ${turn.thought_html}
                ${turn.action ? `<div class="action-text">\n\`\`\`\n${turn.action}\n\`\`\`</div>` : ''}
            </div>
        </div>
        <div class="errors-section">
            <strong>Errors Found:</strong>
            <div class="errors-list">
                ${errorMessages.join('')}
            </div>
        </div>
    `;

    // Append header container and error content to the list item
    listItem.appendChild(headerContainer);
    listItem.appendChild(errorContent);
    
    // Update toggle button click handler
    toggleButton.onclick = function(e) {
        e.stopPropagation();
        const isExpanding = errorContent.style.display === 'none';
        errorContent.style.display = isExpanding ? 'block' : 'none';
        toggleButton.innerHTML = isExpanding ? 
            '<i class="fas fa-chevron-up"></i>' : 
            '<i class="fas fa-chevron-down"></i>';
        copyButton.style.display = isExpanding ? 'flex' : 'none';
    };

    // Add copy button click handler
    copyButton.onclick = function(e) {
        e.stopPropagation();
        // Get the thought text and replace <code> tags with backticks
        let thoughtText = turn.thought_backup.replace(/<code>/g, '`').replace(/<\/code>/g, '`');
        
        const textToCopy = `${thoughtText}${turn.action ? `\n\n\`\`\`\n${turn.action}\n\`\`\`` : ''}`;
        
        navigator.clipboard.writeText(textToCopy).then(() => {
            // Show feedback
            const originalIcon = copyButton.innerHTML;
            copyButton.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                copyButton.innerHTML = originalIcon;
            }, 1500);
        });
    };

    // Remove the click event from the list item itself
    listItem.onclick = null;

    // Append the list item to the error list
    errorList.appendChild(listItem);

    // After appending the modifiedThoughtDiv to the error list
    const copySuggestedButton = document.querySelector('.copy-suggested-thought');
    if (copySuggestedButton) {
        copySuggestedButton.onclick = function(e) {
            e.stopPropagation();
            const textToCopy = geminiAnalysis.suggestedThought; // Ensure this variable is accessible
            navigator.clipboard.writeText(textToCopy).then(() => {
                // Show feedback
                const originalIcon = copySuggestedButton.innerHTML;
                copySuggestedButton.innerHTML = '<i class="fas fa-check"></i>'; // Change icon to checkmark
                setTimeout(() => {
                    copySuggestedButton.innerHTML = originalIcon; // Restore original icon
                }, 1500);
            });
        };
    }
}
// Expose the addTurn function to content.js
window.addTurn = addTurn;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.data) {
        const turns = request.data.turns;

        // First remove the turns that are not in the list
        for (const turnId of checkedTurnIds) {
            if (!turns.some(turn => turn.ID === turnId)) {
                const listItem = document.getElementById(turnId);
                if (listItem) {
                    listItem.remove();
                }
                checkedTurnIds = checkedTurnIds.filter(id => id !== turnId);
            }
        }
        // Set turnNumber to the current length of the error list + 1
        let turnNumber = document.getElementById('errorList').children.length + 1;

        // Process each turn sequentially
        async function processTurns() {
            for (const turn of turns) {
                // Check if the turn ID is already checked
                const isChecked = checkedTurnIds.includes(turn.ID);
                
                // If not checked, add it to the list and process it
                if (!isChecked) {
                    const analysisResults = await analyzeTurn(turn);
                    window.addTurn(turnNumber, turn, analysisResults);
                    checkedTurnIds.push(turn.ID); // Add the ID to the checked list
                    turnNumber++;
                }
            }

            // If no IDs are checked, mark all turns as checked
            if (checkedTurnIds.length === 0) {
                for (const turn of turns) {
                    checkedTurnIds.push(turn.ID); // Mark all as checked
                    const analysisResults = await analyzeTurn(turn);
                    window.addTurn(turnNumber, turn, analysisResults);
                    turnNumber++;
                }
            }
        }

        processTurns();
    }
    else if(request.IDS){
        const turns = request.IDS.turns;
        console.log(turns);
        // Remove turns that do not exist in the provided list of IDs
        turns.forEach(turn => {
            if (!checkedTurnIds.includes(turn.ID)) {
                // Find the corresponding list item and remove it
                const listItem = document.getElementById(turn.ID); // Updated to use getElementById
                if (listItem) {
                    listItem.remove(); // Remove the turn from the UI
                }
            }
        });
    }
});


async function analyzeTurn(turn) {
    // Perform regular analysis
    const regularAnalysis = performRegularAnalysis(turn);
    
    // Determine which analysis function to use based on PREFERED_MODEL
    let geminiAnalysis = null;
    if (PREFERED_MODEL === 'gemini') {
        // Perform Gemini analysis
        geminiAnalysis = await analyzeWithGemini(turn);
    } else if (PREFERED_MODEL === 'gpt') {
        // Perform GPT analysis (assuming you have a function for this)
        geminiAnalysis = await analyzeWithGPT(turn);
    }
     
    // Combine both analyses
    return {
        ...regularAnalysis,
        geminiAnalysis
    };
}

// Move existing analysis logic to a separate function
function performRegularAnalysis(turn) {
    // analyze turns
    const WORD_MISTAKES_PATTERN = new RegExp(`\\b(?:${WORD_MISTAKES.map(word => escapeRegExp(word)).join('|')})\\b`, 'i');
    turn.analysis = {};
    // Initialize errors as an empty array if it doesn't exist
    turn.analysis.errors = []; // Ensure errors is an array
    //console.log(turn);

    const thought = turn.thought || '';
    const action = turn.action || '';
    const status = turn.metadata.status_message || '';


    // error: unmatched_backticks
    const unmatchedBackticks = (thought.match(/`/g) || []).length % 2 !== 0;
    if (unmatchedBackticks) {
        turn.analysis.errors.error_unmatched_backticks = true;
    }
    
    // error: verbosity
    const thoughtCharLength = thought.length; // Get the length of the thought
    if (thoughtCharLength >= 650) {
        turn.analysis.errors.error_turn_verbosity = thoughtCharLength; // Add verbosity error
    }
    
    // Exclude text within backticks for word mistakes evaluation
    const thoughtWithoutBackticks = thought.replace(/`[^`]*`/g, ''); // Remove text between backticks
    const wordMistakeMatches = thoughtWithoutBackticks.match(WORD_MISTAKES_PATTERN) || [];
    if (wordMistakeMatches.length) {
        turn.analysis.errors.error_word_mistakes = wordMistakeMatches;
    }

    // error: no ends with dot
    if (!thought.trim().endsWith('.')) {
        turn.analysis.errors.error_no_ends_with_dot = true;
    } else if (thought.trim().endsWith('..')) { // Check for more than one dot
        turn.analysis.errors.error_no_ends_with_dot = true; // You can use a different error type if needed
    }

    // error: more than one consecutive space
    if (/\s{2,}/.test(thought)) {
        turn.analysis.errors.error_consecutive_spaces = true; // Add error for consecutive spaces
    }

    // error: numbers not in thought
    if (action.toLowerCase().includes("edit")) {
        const editNumbers = [...action.matchAll(/edit\s+(\d+):(\d+)/g)].map(match => match.slice(1));
        if (editNumbers.length) {
            const [first, second] = editNumbers[0];
            if (first !== '1' && second !== '1') {
                const editNumbersInThought = [first, second].every(num => thought.includes(num));
                if (!editNumbersInThought) {
                    turn.analysis.errors.error_edit_numbers_not_in_thought = true;
                }
            }
        }
    }

    

    // error: camelcase words no backticks
    const camelcaseErrors = [];
    const camelcaseMatches = thoughtWithoutBackticks.match(CAMELCASE_PATTERN) || [];
    camelcaseMatches.forEach(camelcaseMatch => {
        if (!thought.includes(`\`${camelcaseMatch}\``)) {
            camelcaseErrors.push(camelcaseMatch);
        }
    });

    // error: uppercase words no backticks
    const uppercaseErrors = [];
    const uppercaseMatches = thoughtWithoutBackticks.match(UPPERCASE_PATTERN) || [];
    uppercaseMatches.forEach(uppercaseMatch => {
        if (!thought.includes(`\`${uppercaseMatch}\``)) {
            uppercaseErrors.push(uppercaseMatch);
        }
    });

    if (uppercaseErrors.length > 0) {
        turn.analysis.errors.error_uppercase_no_backticks = uppercaseErrors;
    }

    // error: common words no backticks
    const commonWordErrors = [];
    COMMON_WORDS.forEach(commonWord => {
        if (thought.includes(` ${commonWord} `) && !thought.includes(`\`${commonWord}\``)) {
            commonWordErrors.push(commonWord);
        }
    });

    if (commonWordErrors.length > 0) {
        turn.analysis.errors.error_common_word_no_backticks = commonWordErrors;
    }

    // error: snakecase words no backticks
    const snakecaseErrors = [];
    const snakecaseMatches = thoughtWithoutBackticks.match(SNAKECASE_PATTERN) || [];
    snakecaseMatches.forEach(snakecaseMatch => {
        const startIndex = thoughtWithoutBackticks.indexOf(snakecaseMatch);
        const endIndex = startIndex + snakecaseMatch.length;

        if ((endIndex < thoughtWithoutBackticks.length && (thoughtWithoutBackticks.substring(endIndex, endIndex + 3) === '.py' || thoughtWithoutBackticks.substring(endIndex, endIndex + 2) === '()'))) {
            return;
        }

        if ((startIndex > 0 && ['.', '('].includes(thoughtWithoutBackticks[startIndex - 1])) || (endIndex < thoughtWithoutBackticks.length && thoughtWithoutBackticks[endIndex] === '.')) {
            return;
        }

        if (!thoughtWithoutBackticks.includes(`\`${snakecaseMatch}\``)) {
            snakecaseErrors.push(snakecaseMatch);
        }
    });

    if (snakecaseErrors.length > 0) {
        turn.analysis.errors.error_snakecase_no_backticks = snakecaseErrors;
    }

    // error: path no backticks
    const pathErrors = [];
    const pathMatches = thoughtWithoutBackticks.match(PATH_PATTERN) || [];
    pathMatches.forEach(pathMatch => {
        if (!thoughtWithoutBackticks.includes(`\`${pathMatch}\``)) {
            pathErrors.push(pathMatch);
        }
    });

    if (pathErrors.length > 0) {
        turn.analysis.errors.error_path_no_backticks = pathErrors;
    }

    const misspelledWords = checkMisspelledWords(thought);
    if (misspelledWords.length > 0) {
        turn.analysis.errors.error_spell_checker = misspelledWords.map(misspelledWord => ({
            error: misspelledWord,
            correction_candidate: dictionary.suggest(misspelledWord)[0] || null
        }));
    }
    // Check if action is submit and status is not completed
    
    if (action.toLowerCase().includes("submit") && status.toLowerCase() !== "success") {
        console.log(status.toLowerCase());
        turn.analysis.errors.error_not_submit_action = true;
    }
    //console.log(turn);
    return turn;
}

function checkMisspelledWords(thought) {
    // Convert WORD_EXCEPTIONS_SPELL_CHECKER to a Set for faster lookups
    const exceptionsSet = new Set(WORD_EXCEPTIONS_SPELL_CHECKER);

    // Remove possessive "'s" and contractions first
    const thoughtWithoutPossessives = thought.replace(/(\w+)'s/g, '$1'); // Remove possessive "'s"
    const thoughtWithoutContractions = thoughtWithoutPossessives.replace(/\b(\w+)'(ll|ve|re|m|s|d|t)\b/g, '$1'); // Remove contractions

    // Process text to remove words between backticks first
    const thoughtWithoutQuotedWords = thoughtWithoutContractions.replace(/`[^`]*`|\"[^\"]*\"|'[^']*'/g, ''); // Remove words between backticks, double quotes, and single quotes

    // Split the thought into words and filter out exceptions first
    const wordsArray = thoughtWithoutQuotedWords.split(/\s+/);
    console.log(exceptionsSet);
    const words = wordsArray.filter(word => word.trim() !== '' && !exceptionsSet.has(word) && isNaN(word)); // Exclude numeric words

    // Remove any remaining non-word characters
    const filteredWords = words.map(word => word.replace(/[^\w\s]|_/g, '').trim())
        .filter(word => isNaN(word)); // Exclude numbers

    // Evaluate filtered words against the dictionary for misspellings
    const misspelledWords = filteredWords.filter(word => word !== '' && !dictionary.check(word)); // Check each word against the dictionary

    return misspelledWords; // Return only the misspelled words

}

// Helper function to escape regex special characters
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

let checkedTurnIds = []; // Array to store checked turn IDs


document.getElementById('copy-all-turns').onclick = function() {
    const turnTexts = Array.from(document.querySelectorAll('.turn-text'))
        .map(turn => turn.innerText.trim()) // Trim leading whitespace
        .join('\n\n');
    
    navigator.clipboard.writeText(turnTexts).then(() => {
        // Show feedback
        showPopup('All turns copied to clipboard!'); // Call the popup function
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
};

// Function to show a popup notification
function showPopup(message) {
    const popup = document.createElement('div');
    popup.className = 'popup-notification'; // Add a class for styling
    popup.innerText = message;
    document.body.appendChild(popup);

    // Set a timeout to remove the popup after a few seconds
    setTimeout(() => {
        popup.remove();
    }, 3000); // Duration in milliseconds (3000ms = 3 seconds)
}

// Add CSS for the popup notification
const style = document.createElement('style');
style.innerHTML = `
    .popup-notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        background-color: rgba(0, 0, 0, 0.7);
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        z-index: 1000;
        transition: opacity 0.5s ease;
    }
`;
document.head.appendChild(style);

document.getElementById('review-all-turns').onclick = function() {

    // Send message to content script to scroll to this ID
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {
            action: 'reviewAllTurns'
        });
    });
    console.log('Reviewing all turns');

};

document.getElementById('be-tool').onclick = function() {
    // Get the current tab's URL
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        const currentUrl = tabs[0].url; // Get the current URL
        const extractedPart = currentUrl.split('.com/?i=')[1]?.split(/&r=|&u=|$/)[0]; // Extract part after '.com/?i=' and before '&r=', '&u=', or end of string

        const newUrl = 'https://indirectly-glowing-cougar.ngrok-free.app/?instance=' + encodeURIComponent(extractedPart); // Replace with your target URL

        // Open the new URL in a new tab
        chrome.tabs.create({ url: newUrl });
    });
};




