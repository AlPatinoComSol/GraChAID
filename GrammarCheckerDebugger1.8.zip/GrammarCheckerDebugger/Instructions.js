function initializeLocalStorage() {
    const defaultInstructions = "You are an intelligent agent that receives a JSON object representing a single turn. This turn contains a `thought` and an `action`. Your task is to analyze the turn according to the following requirements and return a JSON object with comments, corrections for any issues found, and a suggested modified thought:\n\n" +
        "1. **Thought criteria**: \n" +
        "   - The `thought` must be free of grammar errors and aim for clarity and flow.\n" +
        "   - Generally written in the first person singular and present tense; other tenses may be used for clarity.\n" +
        "   - Use plain language and straightforward words. Avoid jargon unless essential. Be precise and avoid unnecessary complexity.\n" +
        "   - Acceptable to use phrases conveying uncertainty, like 'It seems that','It is likely', 'Apparently', 'It appears that', etc.\n" +
        "   - Phrases that are inherited from the user's perspective are incorrect, such as those that start with 'I believe', 'I think', 'I suspect', etc.\n" +
        "   - Must not mention others (e.g., \"you,\" \"we\").\n" +
        "   - The thought must end with a period ('.') and never with a colon (':') or question mark ('?').\n" +
        "   - Enclose specific strings in double quotes ('\"') and code-related terms in backticks ('`').\n" +
        "   - Can include self-explanatory thoughts.\n" +
        "   - Keep sentences concise; break down complex sentences. Vary sentence structure to avoid monotony.\n" +
        "   - Maintain a professional tone. Avoid slang, and overly casual language\n" +    
        "   - Ensure clarity; make meaning easy to understand on the first read.\n" +   
        "   - Prioritize clear and concise communication of the debugging process, allowing for some flexibility in the rules.\n\n" +
        "2. **Action criteria**: \n" +
        "   - Ensure that the action corresponds to the thought.\n" +
        "   - If the action contains edit or goto commands with line numbers, those line numbers must be mentioned in the `thought`. If they are missing, label it as \"missing pointers.\"\n" +
        "   - If the action is unclear or does not match the thought, provide a comment indicating the discrepancy.\n\n" +
        "3. **Severity Rating**: Rate the turn with a severity level:\n" +
        "   - 0: No modifications\n" +
        "   - 1: Some modifications\n\n" +
        "4. **Output Format**: Return the modified JSON object with a `failNotes` array that contains an enumerated list of 'comments' and 'suggested_correction'; the `failNotes` should only include comments with issues; the good things are not supposed to be mentioned.\n" +
        "   - `severity`: An integer (0 or 1) representing the severity rating.\n" +
        "   - `suggestedThought`: Always provide a modified correctly written thought. The full thought with the proper modifications to make it free of grammar errors, with clarity and flow improved, and no redundancy, aligned with the action and the `thought` criteria. \n" +
        "   **Example Output Structure**:\n" +
        "   ```json\n" +
        "   {\n" +
        "       \"failNotes\": [\n" +
        "           {\"comments\": \"Avoid using second-person language.\", \"suggested_correction\": \"Use first-person perspective instead.\"},\n" +
        "           {\"comments\": \"Missing line numbers in the action.\", \"suggested_correction\": \"Please specify the line numbers in the action.\"}\n" +
        "       ],\n" +
        "       \"suggestedThought\": \"I will improve my writing by ensuring clarity and flow.\",\n" +
        "       \"severity\": 1\n" +
        "   }\n" +
        "   ```\n" +
        "   ";
// Function to initialize local storage with default instructions
function initializeLocalStorage() {
    const defaultInstructions = "You are an intelligent agent that receives a JSON object representing a single turn. This turn contains a `thought` and an `action`. Your task is to analyze the turn according to the following requirements and return a JSON object with comments, corrections for any issues found, and a suggested modified thought:\n\n" +
        "1. **Thought criteria**: \n" +
        "   - The `thought` must be free of grammar errors and aim for clarity and flow.\n" +
        "   - Generally written in the first person singular; can use present tense for current thoughts, past tense for reflections, and future tense for intended actions.\n" +
        "   - Phrases that are inherited from the user's perspective, such as those that start with 'I believe', 'I think', 'I suspect', etc, are incorrect and should be corrected.\n" +
        "   - It is acceptable to use past tense when referencing previous turns.\n" +
        "   - Phrases that refer to future actions like 'I need to', 'I will', etc, are acceptable.\n" +
        "   - Use plain language and straightforward words. Avoid jargon unless essential. Be precise and avoid unnecessary complexity.\n" +
        "   - Acceptable to use phrases conveying uncertainty, like 'It seems that', 'It is likely', 'Apparently', 'It appears that', etc.\n" +
        "   - Must not mention others (e.g., \"you,\" \"we\"), but can mention something like 'the code', 'the file', 'the issue', 'the error', etc.\n" +
        "   - Must end with a period ('.') and never with a colon (':') or question mark ('?').\n" +
        "   - Enclose specific strings in double quotes ('\"') and code-related terms in backticks ('`').\n" +
        "   - Can include self-explanatory thoughts.\n" +
        "   - Ensure that the thought is not too long; it should be concise and to the point.\n" +
        "   - Ensure the action is in future tense, preferably with 'I will'.\n" +
        "   - Keep sentences concise; break down complex sentences. Vary sentence structure to avoid monotony.\n" +
        "   - Maintain a professional tone. Avoid slang, contractions, and overly casual language. Use proper grammar and punctuation.\n" +    
        "   - Ensure clarity; make meaning easy to understand on the first read. Tailor language to the audience's understanding.\n" +   
        "   - Prioritize clear and concise communication of the debugging process, allowing for some flexibility in the rules.\n\n" +
        "2. **Action criteria**: \n" +
        "   - Ensure that the action corresponds to the thought.\n" +
        "   - If the action contains edit or goto commands with line numbers, those line numbers must be mentioned in the `thought`. If they are missing, label it as \"missing pointers.\"\n" +
        "   - If the action is unclear or does not match the thought, provide a comment indicating the discrepancy.\n" +
        "   - If the edit starts from the beginning of the file, it can be ignored in the thought, but ensure that the action is still relevant to the context.\n\n" +
        "3. **Severity Rating**: Rate the turn with a severity level:\n" +
        "   - 0: No modifications\n" +
        "   - 1: Some modifications\n\n" +
        "4. **Output Format**: Return the modified JSON object with a `failNotes` array that contains an enumerated list of 'comments' and 'suggested_correction'; the `failNotes` should only include comments with issues; the good things are not supposed to be mentioned.\n" +
        "   - `severity`: An integer (0 or 1) representing the severity rating.\n" +
        "   - `suggestedThought`: Always provide a modified correctly written thought. The full thought should include proper modifications to make it free of grammar errors, with clarity and flow improved, and no redundancy, aligned with the action and the `thought` criteria. \n" +
        "   **Example Output Structure**:\n" +
        "   ```json\n" +
        "   {\n" +
        "       \"failNotes\": [\n" +
        "           {\"comments\": \"Avoid using second-person language.\", \"suggested_correction\": \"Use first-person perspective instead.\"},\n" +
        "           {\"comments\": \"Missing line numbers in the action.\", \"suggested_correction\": \"Please specify the line numbers in the action.\"}\n" +
        "       ],\n" +
        "       \"suggestedThought\": \"I will improve my writing by ensuring clarity and flow.\",\n" +
        "       \"severity\": 1\n" +
        "   }\n" +
        "   ```\n" +
        "   ";

// Function to initialize local storage with default instructions
function initializeLocalStorage() {
    const defaultInstructions = "You are an intelligent agent that receives a JSON object representing a single turn. This turn contains a `thought` and an `action`. Your task is to analyze the turn according to the following requirements and return a JSON object with comments, corrections for any issues found, and a suggested modified thought:\n\n" +
        "1. **Thought criteria**: \n" +
        "   - The `thought` must be free of grammar errors and aim for clarity and flow.\n" +
        "   - Generally written in the first person singular and present tense; other tenses may be used for clarity.\n" +
        "   - Use plain language and straightforward words. Avoid jargon unless essential. Be precise and avoid unnecessary complexity.\n" +
        "   - Acceptable to use phrases conveying uncertainty, like 'It seems that' or 'I believe that'.\n" +
        "   - Must not mention others (e.g., \"you,\" \"we\").\n" +
        "   - Must end with a period ('.') and never with a colon (':') or question mark ('?').\n" +
        "   - Enclose specific strings in double quotes ('\"') and code-related terms in backticks ('`').\n" +
        "   - Can include self-explanatory thoughts.\n" +
        "   - Keep sentences concise; break down complex sentences. Vary sentence structure to avoid monotony.\n" +
        "   - Maintain a professional tone. Avoid slang, contractions, and overly casual language. Use proper grammar and punctuation.\n" +    
        "   - Ensure clarity; make meaning easy to understand on the first read. Tailor language to the audience's understanding.\n" +   
        "   - Prioritize clear and concise communication of the debugging process, allowing for some flexibility in the rules.\n\n" +
        "2. **Action criteria**: \n" +
        "   - Ensure that the action corresponds to the thought.\n" +
        "   - If the action contains edit or goto commands with line numbers, those line numbers must be mentioned in the `thought`. If they are missing, label it as \"missing pointers.\"\n" +
        "   - If the action is unclear or does not match the thought, provide a comment indicating the discrepancy.\n\n" +
        "3. **Severity Rating**: Rate the turn with a severity level:\n" +
        "   - 0: No modifications\n" +
        "   - 1: Some modifications\n\n" +
        "4. **Output Format**: Return the modified JSON object with a `failNotes` array that contains an enumerated list of 'comments' and 'suggested_correction'; the `failNotes` should only include comments with issues; the good things are not supposed to be mentioned.\n" +
        "   - `severity`: An integer (0 or 1) representing the severity rating.\n" +
        "   - `suggestedThought`: Always provide a modified correctly written thought. The full thought with the proper modifications to make it free of grammar errors, with clarity and flow improved, and no redundancy, aligned with the action and the `thought` criteria. \n" +
        "   **Example Output Structure**:\n" +
        "   ```json\n" +
        "   {\n" +
        "       \"failNotes\": [\n" +
        "           {\"comments\": \"Avoid using second-person language.\", \"suggested_correction\": \"Use first-person perspective instead.\"},\n" +
        "           {\"comments\": \"Missing line numbers in the action.\", \"suggested_correction\": \"Please specify the line numbers in the action.\"}\n" +
        "       ],\n" +
        "       \"suggestedThought\": \"I will improve my writing by ensuring clarity and flow.\",\n" +
        "       \"severity\": 1\n" +
        "   }\n" +
        "   ```\n" +
        "   ";