import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: "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",
});

const completion = openai.chat.completions.create({
  model: "gpt-4o-mini",
  store: true,
  messages: [
    {"role": "user", "content": "write a haiku about ai"},
  ],
});

completion.then((result) => console.log(result.choices[0].message));