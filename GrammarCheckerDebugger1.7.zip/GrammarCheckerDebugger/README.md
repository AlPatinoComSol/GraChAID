# Grammar Evaluator

The Grammar Evaluator is a Chrome extension designed to evaluate the grammar of THE AI DEBUGGER.

## Table of Contents

- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Contributing](#contributing)
- [License](#license)

## Features

- **Real-time Grammar Checking**: Automatically checks grammar as you type.
- **Error Highlighting**: Highlights grammatical errors in the text.
- **Suggestions for Corrections**: Provides suggestions for correcting identified errors.
- **User-Friendly Interface**: Easy to use with a clean and intuitive design.
- **Side Panel Integration**: Opens a side panel in the browser for detailed error analysis.

## Installation

To install the Grammar Evaluator extension, follow these steps:

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/grammar-evaluator.git
   cd grammar-evaluator
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Load the extension in Chrome:
   - Open Chrome and navigate to `chrome://extensions/`.
   - Enable "Developer mode" in the top right corner.
   - Click on "Load unpacked" and select the directory where the project is located.

## Usage

Once the extension is installed, you can use it as follows:

1. Open the ai debugger.
2. Start as usual. 
3. When you click next, the side panel will display any grammatical errors found along with suggestions for corrections.

[LartamCoders]
