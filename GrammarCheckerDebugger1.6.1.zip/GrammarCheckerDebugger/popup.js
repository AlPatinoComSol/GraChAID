document.addEventListener('DOMContentLoaded', function() {
    // Ensure the browser's side panel is ready
    if (!isSidePanelAvailable()) {
        console.error("Browser side panel not found.");
        return; // Exit if the side panel is not found
    }

    document.getElementById('checkGrammar').addEventListener('click', function() {
        fetch('sidePanel.html') // Load the side panel HTML
            .then(response => response.text())
            .then(data => {
                openBrowserSidePanel(data); // Load into the browser's side panel
                // Close the popup after opening the side panel
                window.close();
            });
    });

    // Add handler for GitHub link
    document.querySelectorAll('nav a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            chrome.tabs.create({ url: this.href });
        });
    });
});

// Function to check if the side panel is available
function isSidePanelAvailable() {
    // Check if the browser supports the sidePanel API
    return !!chrome.sidePanel; 
}

function openBrowserSidePanel(content) {
    if (isSidePanelAvailable()) {
        // 1. Get the active tab ID
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0) {
                const tabId = tabs[0].id;

                // 2. Set the side panel options for the specific tab
                chrome.sidePanel.setOptions({
                    tabId: tabId,
                    path: 'sidePanel.html',
                    enabled: true,
                });

                // 4. Open the side panel
                chrome.sidePanel.open({ tabId: tabId }); 
            }
        });
    } else {
        console.error("Side panel API is not available."); 
    }
}
