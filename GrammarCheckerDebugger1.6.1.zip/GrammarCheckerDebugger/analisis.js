// my-chrome-extension/first/analysis.js
const SpellChecker = require('spellchecker'); // Assuming a similar spell checker library is available
const { WORD_MISTAKES, CAMELCASE_PATTERN, SNAKECASE_PATTERN, PATH_PATTERN, UPPERCASE_PATTERN, COMMON_WORDS, WORD_EXCEPTIONS_SPELL_CHECKER } = require('./config');

const spell = new SpellChecker();

function analysis(data) {
    data.analysis = {};

    // has no turns
    data.analysis.empty_turns = data.turns.length;
    if (data.analysis.empty_turns === 0) {
        return;
    }

    // error: ends with submit runned
    const lastTurn = data.turns[data.turns.length - 1] || null;
    data.analysis.last_turn = {
        action: lastTurn.action,
        status: lastTurn.metadata.status,
    };

    // analyze turns
    const WORD_MISTAKES_PATTERN = new RegExp(`\\b(?:${WORD_MISTAKES.map(word => escapeRegExp(word)).join('|')})\\b`, 'i');
    data.turns.forEach(turn => {
        turn.analysis = {};
        const thought = turn.thought || '';

        // error: word mistakes
        const wordMistakeMatches = thought.match(WORD_MISTAKES_PATTERN) || [];
        if (wordMistakeMatches.length) {
            turn.analysis.error_word_mistakes = wordMistakeMatches;
        }

        // error: no ends with dot
        if (!thought.trim().endsWith('.')) {
            turn.analysis.error_no_ends_with_dot = true;
        }

        // error: numbers not in thought
        if (turn.action.toLowerCase().includes("edit")) {
            const editNumbers = [...turn.action.matchAll(/edit\s+(\d+):(\d+)/g)].map(match => match.slice(1));
            if (editNumbers.length) {
                const [first, second] = editNumbers[0];
                if (first !== '1' && second !== '1') {
                    const editNumbersInThought = [first, second].every(num => thought.includes(num));
                    if (!editNumbersInThought) {
                        turn.analysis.error_edit_numbers_not_in_thought = true;
                    }
                }
            }
        }

        // error: unmatched_backticks
        const unmatchedBackticks = (thought.match(/`/g) || []).length % 2 !== 0;
        if (unmatchedBackticks) {
            turn.analysis.error_unmatched_backticks = true;
        }

        // error: camelcase words no backticks
        const camelcaseErrors = [];
        const camelcaseMatches = thought.match(CAMELCASE_PATTERN) || [];
        camelcaseMatches.forEach(camelcaseMatch => {
            if (!thought.includes(`\`${camelcaseMatch}\``)) {
                camelcaseErrors.push(camelcaseMatch);
            }
        });

        // error: uppercase words no backticks
        const uppercaseErrors = [];
        const uppercaseMatches = thought.match(UPPERCASE_PATTERN) || [];
        uppercaseMatches.forEach(uppercaseMatch => {
            if (!thought.includes(`\`${uppercaseMatch}\``)) {
                uppercaseErrors.push(uppercaseMatch);
            }
        });

        if (uppercaseErrors.length > 0) {
            turn.analysis.error_uppercase_no_backticks = uppercaseErrors;
        }

        // error: common words no backticks
        const commonWordErrors = [];
        COMMON_WORDS.forEach(commonWord => {
            if (thought.includes(` ${commonWord} `) && !thought.includes(`\`${commonWord}\``)) {
                commonWordErrors.push(commonWord);
            }
        });

        if (commonWordErrors.length > 0) {
            turn.analysis.error_common_word_no_backticks = commonWordErrors;
        }

        // error: snakecase words no backticks
        const snakecaseErrors = [];
        const snakecaseMatches = thought.match(SNAKECASE_PATTERN) || [];
        snakecaseMatches.forEach(snakecaseMatch => {
            const startIndex = thought.indexOf(snakecaseMatch);
            const endIndex = startIndex + snakecaseMatch.length;

            if ((endIndex < thought.length && (thought.substring(endIndex, endIndex + 3) === '.py' || thought.substring(endIndex, endIndex + 2) === '()'))) {
                return;
            }

            if ((startIndex > 0 && ['.', '('].includes(thought[startIndex - 1])) || (endIndex < thought.length && thought[endIndex] === '.')) {
                return;
            }

            if (!thought.includes(`\`${snakecaseMatch}\``)) {
                snakecaseErrors.push(snakecaseMatch);
            }
        });

        if (snakecaseErrors.length > 0) {
            turn.analysis.error_snakecase_no_backticks = snakecaseErrors;
        }

        // error: path no backticks
        const pathErrors = [];
        const pathMatches = thought.match(PATH_PATTERN) || [];
        pathMatches.forEach(pathMatch => {
            if (!thought.includes(`\`${pathMatch}\``)) {
                pathErrors.push(pathMatch);
            }
        });

        if (pathErrors.length > 0) {
            turn.analysis.error_path_no_backticks = pathErrors;
        }

        // error: spell checker
        const thoughtWithoutBacktickWords = thought.replace(/`([^`]*)`/g, '').split(/\s+/);
        const punctuationToRemove = /[^\w\s]/g; // Adjust as needed
        const filteredWords = thoughtWithoutBacktickWords.map(word => word.replace(punctuationToRemove, '')).filter(word => !WORD_EXCEPTIONS_SPELL_CHECKER.includes(word));

        // Detect misspelled words
        const misspelledWords = filteredWords.filter(word => spell.isMisspelled(word));
        if (misspelledWords.length > 0) {
            turn.analysis.error_spell_checker = misspelledWords.map(misspelledWord => ({
                error: misspelledWord,
                correction_candidate: spell.getCorrectionsForMisspelling(misspelledWord)[0] || null,
            }));
        }
    });

    // last turn not submit/executed
    const lastTurnFinal = data.turns[data.turns.length - 1] || null;
    if (lastTurnFinal) {
        if (lastTurnFinal.action.includes('submit') && lastTurnFinal.metadata.status !== true) {
            lastTurnFinal.analysis = {};
            lastTurnFinal.analysis.error_not_submit_action = true;
        }
    }

    return data;
}

// Helper function to escape regex special characters
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

module.exports = analysis;