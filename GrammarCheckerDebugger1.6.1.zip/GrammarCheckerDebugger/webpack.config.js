const path = require('path');
const webpack = require('webpack');
require('dotenv').config();

module.exports = {
    entry: './sidePanel.js',
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist'),
    },
    mode: 'development',
    devtool: 'source-map',
    module: {
        rules: [
            {
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-env']
                    }
                }
            }
        ]
    },
    plugins: [
        new webpack.DefinePlugin({
            'process.env.GEMINI_API_KEY': JSON.stringify(process.env.GEMINI_API_KEY)
        })
    ]
};