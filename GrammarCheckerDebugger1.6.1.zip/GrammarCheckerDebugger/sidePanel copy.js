/*
import { 
    WORD_MISTAKES, 
    CAMELCASE_PATTERN, 
    SNAKECASE_PATTERN, 
    PATH_PATTERN, 
    UPPERCASE_PATTERN, 
    COMMON_WORDS, 
    WORD_EXCEPTIONS_SPELL_CHECKER 
} from './config.js';
*/
import Typo from 'typo-js';

var dictionary = new Typo("en_US", false, false, { dictionaryPath: "/node_modules/typo-js/dictionaries" });

// Add these variables at the top of your file
let currentRound = 1;
let activeRound = 1;

function getReadableErrorMessage(errorType, error) {
    const errorMessages = {
        error_word_mistakes: {
            title: "Word Usage Error",
            description: word => `The word "${word}" might be inappropriate or incorrect in this context.`
        },
        error_no_ends_with_dot: {
            title: "Missing Period",
            description: "The thought should end with a period (.)"
        },
        error_edit_numbers_not_in_thought: {
            title: "Missing Line Numbers",
            description: "The edit line numbers should be mentioned in the thought."
        },
        error_unmatched_backticks: {
            title: "Unmatched Code Markers",
            description: "There are unmatched backticks (`) in the text. Code snippets should be wrapped in pairs of backticks."
        },
        error_uppercase_no_backticks: {
            title: "Unmarked Code (Uppercase)",
            description: word => `The uppercase term "${word}" should be wrapped in backticks.`
        },
        error_common_word_no_backticks: {
            title: "Unmarked Technical Term",
            description: word => `The technical term "${word}" should be wrapped in backticks.`
        },
        error_snakecase_no_backticks: {
            title: "Unmarked Code (Snake Case)",
            description: word => `The snake_case term "${word}" should be wrapped in backticks.`
        },
        error_path_no_backticks: {
            title: "Unmarked File Path",
            description: path => `The file path "${path}" should be wrapped in backticks.`
        },
        error_spell_checker: {
            title: "Possible Spelling Error",
            description: (word, suggestion) => `"${word}" might be misspelled${suggestion ? `. Did you mean "${suggestion}"?` : '.'}`
        },
        error_not_submit_action: {
            title: "Incomplete Submit Action",
            description: "The submit action was not completed successfully."
        }
    };

    return errorMessages[errorType] || { 
        title: "Unknown Error",
        description: "An unspecified error occurred."
    };
}

function checkMisspelledWords(thought) {
    // Process text to remove words between backticks and punctuation
    const thoughtWithoutBacktickWords = thought.replace(/`[^`]*`/g, '').split(/\s+/);
    const punctuationToRemove = /[^\w\s]|_|[.,:;\\`]/g; // Updated regex to remove additional punctuation

    // First filter out words in WORD_EXCEPTIONS_SPELL_CHECKER, then remove punctuation
    const filteredWords = thoughtWithoutBacktickWords
        .filter(word => word && !WORD_EXCEPTIONS_SPELL_CHECKER.has(word)) // Filter out exceptions first
        .map(word => word.replace(punctuationToRemove, '')); // Then remove punctuation

    // Evaluate filtered words against the dictionary for misspellings
    const misspelledWords = filteredWords.filter(word => !dictionary.check(word)); // Check each word against the dictionary

    return misspelledWords; // Return only the misspelled words
}

// Function to add a new round
function addRound(roundNumber) {
    const roundList = document.getElementById('roundList');
    const roundItem = document.createElement('li');
    roundItem.className = 'round-item';
    roundItem.textContent = `R${roundNumber}`;
    roundItem.dataset.round = roundNumber;
    
    // Make the new round active
    document.querySelectorAll('.round-item').forEach(item => {
        item.classList.remove('active');
    });
    roundItem.classList.add('active');
    
    roundItem.addEventListener('click', () => {
        // Handle round selection
        document.querySelectorAll('.round-item').forEach(item => {
            item.classList.remove('active');
        });
        roundItem.classList.add('active');
        activeRound = roundNumber;
        
        // Filter turns to show only those from this round
        showTurnsForRound(roundNumber);
    });
    
    roundList.appendChild(roundItem);
}

// Function to show turns for a specific round
function showTurnsForRound(roundNumber) {
    const allTurns = document.querySelectorAll('#errorList li');
    allTurns.forEach(turn => {
        const turnRound = turn.dataset.round;
        turn.style.display = turnRound == roundNumber ? 'block' : 'none';
    });
}

// Function to add a turn to the sidebar
function addTurn(turnNumber, turn, analysisResults) {
    const errorList = document.getElementById('errorList');
    
    // Create a list item for the turn
    const listItem = document.createElement('li');
    
    // Set background color based on the presence of errors
    if (Object.keys(analysisResults.analysis.errors).length > 0) { 
        listItem.style.backgroundColor = 'rgba(255, 0, 0, 0.3)';
    } else {
        listItem.style.backgroundColor = 'rgba(0, 255, 0, 0.3)';
    }

    // Create a container for the header content (turn info and button)
    const headerContainer = document.createElement('div');
    headerContainer.className = 'turn-header';

    // Create a div to hold the visible content
    const visibleContent = document.createElement('div');
    visibleContent.innerHTML = `<strong>#</strong> ${turnNumber} - <strong>ID:</strong> ${turn.ID}`;

    // Create toggle button
    const toggleButton = document.createElement('button');
    toggleButton.className = 'toggle-button';
    toggleButton.innerHTML = '<i class="fas fa-chevron-down"></i>';

    // Create copy button
    const copyButton = document.createElement('button');
    copyButton.className = 'copy-button';
    copyButton.innerHTML = '<i class="fas fa-copy"></i>';
    copyButton.style.display = 'none'; // Initially hidden
    
    // Create button container
    const buttonContainer = document.createElement('div');
    buttonContainer.className = 'button-container';
    buttonContainer.appendChild(copyButton);
    buttonContainer.appendChild(toggleButton);

    // Add visible content and buttons to header container
    headerContainer.appendChild(visibleContent);
    headerContainer.appendChild(buttonContainer);

    // Create a div to hold the errors (initially hidden)
    const errorContent = document.createElement('div');
    errorContent.className = 'error-content';
    errorContent.style.display = 'none';

    // Build error messages line by line with better formatting
    let errorMessages = [];
    for (const errorType in analysisResults.analysis.errors) {
        const errorValue = analysisResults.analysis.errors[errorType];
        const errorInfo = getReadableErrorMessage(errorType);
        
        if (Array.isArray(errorValue)) {
            if (errorType === 'error_spell_checker') {
                errorValue.forEach(errorObj => {
                    errorMessages.push(`
                        <div class="error-item">
                            <div class="error-title">${errorInfo.title}</div>
                            <div class="error-description">
                                ${errorInfo.description(errorObj.error, errorObj.correction_candidate)}
                            </div>
                        </div>
                    `);
                });
            } else {
                errorValue.forEach(error => {
                    errorMessages.push(`
                        <div class="error-item">
                            <div class="error-title">${errorInfo.title}</div>
                            <div class="error-description">
                                ${errorInfo.description(error)}
                            </div>
                        </div>
                    `);
                });
            }
        } else {
            errorMessages.push(`
                <div class="error-item">
                    <div class="error-title">${errorInfo.title}</div>
                    <div class="error-description">
                        ${errorInfo.description}
                    </div>
                </div>
            `);
        }
    }

    errorContent.innerHTML = `
        <strong>Turn Text:</strong>
        <div class="turn-text">
            <div class="text-content">
                ${turn.thought_html}
                ${turn.action ? `<div class="action-text">\`\`\`\n${turn.action}\n\`\`\`</div>` : ''}
            </div>
        </div>
        <div class="errors-section">
            <strong>Errors Found:</strong>
            <div class="errors-list">
                ${errorMessages.join('')}
            </div>
        </div>
    `;

    // Append header container and error content to the list item
    listItem.appendChild(headerContainer);
    listItem.appendChild(errorContent);
    
    // Update toggle button click handler
    toggleButton.onclick = function(e) {
        e.stopPropagation();
        const isExpanding = errorContent.style.display === 'none';
        errorContent.style.display = isExpanding ? 'block' : 'none';
        toggleButton.innerHTML = isExpanding ? 
            '<i class="fas fa-chevron-up"></i>' : 
            '<i class="fas fa-chevron-down"></i>';
        copyButton.style.display = isExpanding ? 'flex' : 'none';
    };

    // Add copy button click handler
    copyButton.onclick = function(e) {
        e.stopPropagation();
        // Convert the HTML thought to plain text with backticks
        const thoughtText = turn.thought_html
            .replace(/<code>/g, '`')
            .replace(/<\/code>/g, '`')
            .replace(/<[^>]*>/g, ''); // Remove any other HTML tags

        const textToCopy = `Turn #${turnNumber}\n\n${thoughtText}${turn.action ? `\n\nAction:\n\`\`\`\n${turn.action}\n\`\`\`` : ''}`;
        
        navigator.clipboard.writeText(textToCopy).then(() => {
            // Show feedback
            const originalIcon = copyButton.innerHTML;
            copyButton.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                copyButton.innerHTML = originalIcon;
            }, 1500);
        });
    };

    // Remove the click event from the list item itself
    listItem.onclick = null;

    // Add round information to the list item
    listItem.dataset.round = currentRound;

    // Append the list item to the error list
    errorList.appendChild(listItem);
}
// Expose the addTurn function to content.js
window.addTurn = addTurn;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    if (request.data) {
        var data = request.data;
        //console.log(data);

        // Check if this is a revert action
        const isRevert = data.turns.some(turn => 
            turn.action && turn.action.toLowerCase().includes('revert')
        );
        
        if (isRevert) {
            // Start a new round
            currentRound++;
            addRound(currentRound);
        }
        
        // Clear the error list only if it's a new round
        if (isRevert) {
            const errorList = document.getElementById('errorList');
            errorList.innerHTML = '';
        }
        
        // Add the first round if it doesn't exist
        if (!document.querySelector('.round-item')) {
            addRound(1);
        }
        
        const turns = data.turns;
        let turnNumber = 1;
        
        turns.forEach(turn => {
            const analysisResults = analyzeTurn(turn);
            window.addTurn(turnNumber, turn, analysisResults);
            turnNumber++;
        });
    }
});


function analyzeTurn(turn) {
    // analyze turns
    const WORD_MISTAKES_PATTERN = new RegExp(`\\b(?:${WORD_MISTAKES.map(word => escapeRegExp(word)).join('|')})\\b`, 'i');
    turn.analysis = {};
    // Initialize errors as an empty array if it doesn't exist
    turn.analysis.errors = []; // Ensure errors is an array
    //console.log(turn);

    const thought = turn.thought || '';
    const action = turn.action || '';
    const status = turn.metadata.status_message || '';
    // error: word mistakes
    const wordMistakeMatches = thought.match(WORD_MISTAKES_PATTERN) || [];
    if (wordMistakeMatches.length) {
        turn.analysis.errors.error_word_mistakes = wordMistakeMatches;
    }

    // error: no ends with dot
    if (!thought.trim().endsWith('.')) {
        turn.analysis.errors.error_no_ends_with_dot = true;
    }

    // error: numbers not in thought
    if (action.toLowerCase().includes("edit")) {
        const editNumbers = [...action.matchAll(/edit\s+(\d+):(\d+)/g)].map(match => match.slice(1));
        if (editNumbers.length) {
            const [first, second] = editNumbers[0];
            if (first !== '1' && second !== '1') {
                const editNumbersInThought = [first, second].every(num => thought.includes(num));
                if (!editNumbersInThought) {
                    turn.analysis.errors.error_edit_numbers_not_in_thought = true;
                }
            }
        }
    }

    // error: unmatched_backticks
    const unmatchedBackticks = (thought.match(/`/g) || []).length % 2 !== 0;
    if (unmatchedBackticks) {
        turn.analysis.errors.error_unmatched_backticks = true;
    }

    // error: camelcase words no backticks
    const camelcaseErrors = [];
    const camelcaseMatches = thought.match(CAMELCASE_PATTERN) || [];
    camelcaseMatches.forEach(camelcaseMatch => {
        if (!thought.includes(`\`${camelcaseMatch}\``)) {
            camelcaseErrors.push(camelcaseMatch);
        }
    });

    // error: uppercase words no backticks
    const uppercaseErrors = [];
    const uppercaseMatches = thought.match(UPPERCASE_PATTERN) || [];
    uppercaseMatches.forEach(uppercaseMatch => {
        if (!thought.includes(`\`${uppercaseMatch}\``)) {
            uppercaseErrors.push(uppercaseMatch);
        }
    });

    if (uppercaseErrors.length > 0) {
        turn.analysis.errors.error_uppercase_no_backticks = uppercaseErrors;
    }

    // error: common words no backticks
    const commonWordErrors = [];
    COMMON_WORDS.forEach(commonWord => {
        if (thought.includes(` ${commonWord} `) && !thought.includes(`\`${commonWord}\``)) {
            commonWordErrors.push(commonWord);
        }
    });

    if (commonWordErrors.length > 0) {
        turn.analysis.errors.error_common_word_no_backticks = commonWordErrors;
    }

    // error: snakecase words no backticks
    const snakecaseErrors = [];
    const snakecaseMatches = thought.match(SNAKECASE_PATTERN) || [];
    snakecaseMatches.forEach(snakecaseMatch => {
        const startIndex = thought.indexOf(snakecaseMatch);
        const endIndex = startIndex + snakecaseMatch.length;

        if ((endIndex < thought.length && (thought.substring(endIndex, endIndex + 3) === '.py' || thought.substring(endIndex, endIndex + 2) === '()'))) {
            return;
        }

        if ((startIndex > 0 && ['.', '('].includes(thought[startIndex - 1])) || (endIndex < thought.length && thought[endIndex] === '.')) {
            return;
        }

        if (!thought.includes(`\`${snakecaseMatch}\``)) {
            snakecaseErrors.push(snakecaseMatch);
        }
    });

    if (snakecaseErrors.length > 0) {
        turn.analysis.errors.error_snakecase_no_backticks = snakecaseErrors;
    }

    // error: path no backticks
    const pathErrors = [];
    const pathMatches = thought.match(PATH_PATTERN) || [];
    pathMatches.forEach(pathMatch => {
        if (!thought.includes(`\`${pathMatch}\``)) {
            pathErrors.push(pathMatch);
        }
    });

    if (pathErrors.length > 0) {
        turn.analysis.errors.error_path_no_backticks = pathErrors;
    }

    const misspelledWords = checkMisspelledWords(thought);
    if (misspelledWords.length > 0) {
        turn.analysis.errors.error_spell_checker = misspelledWords.map(misspelledWord => ({
            error: misspelledWord,
            correction_candidate: dictionary.suggest(misspelledWord)[0] || null
        }));
    }
    // Check if action is submit and status is not completed
    if (action.toLowerCase().includes("submit") && status.toLowerCase() !== "Submitted changes") {
        turn.analysis.errors.error_not_submit_action = true;
    }
    console.log(turn);
    return turn;
}

// Helper function to escape regex special characters
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}


