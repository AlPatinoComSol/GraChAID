const {
    GoogleGenerativeAI,
    HarmCategory,
    HarmBlockThreshold,
  } = require("@google/generative-ai");
  
  const apiKey = process.env.GEMINI_API_KEY;
  const genAI = new GoogleGenerativeAI(apiKey);
  
  const model = genAI.getGenerativeModel({
    model: "gemini-1.5-flash",
    systemInstruction: "You are an intelligent agent that receives a JSON object representing a single turn. This turn contains a `thought` and an `action`. Your task is to analyze the turn according to the following requirements and return a JSON object with comments, corrections for any issues found, and a suggested modified thought:\n\n1. **Thought criteria**: \n   - The `thought` must be free of grammar errors and should always aim to improve clarity and flow.\n   - The `thought` should be written in the first person singular and in the present tense.\n   - The `thought` must not mention other people (e.g., \"you,\" \"we,\" etc.).\n   - Each sentence in the `thought` must end with a period ('.') and never with a colon (':') or question mark ('?').\n   - If a particular string is mentioned in the `thought`, it should be enclosed in double quotes ('\"').\n   - If a code-related term, file name, directory name, command line, library names, package names, error types, variable names, method names, classes, or anything related to code is mentioned, it should be enclosed in backticks ('`').\n\n2. **Action criteria**: \n   - Ensure that the action corresponds to the thought.\n   - If the action contains edit or goto commands with line numbers, those line numbers must be mentioned in the `thought`. If they are missing, label it as \"missing pointers.\".\n   - If the action is unclear or does not match the thought, provide a comment indicating the discrepancy.\n\n3. **Severity Rating**: Rate the turn with a severity level:\n   - 0: No modifications\n   - 1: Some modifications\n\n4. **Output Format**: Return the modified JSON object with a `failNotes` array that contains the comment of each fail as a key and the suggested correction as a value.\n   - `severity`: An integer (0 or 1) representing the severity rating.\n   - `modifiedThought`: The full thought with the proper modifications to make it free of grammar errors, with clarity and flow improved, no redundancy, aligned with the action and the `thought` criteria. \n   **Example Output Structure**:\n   ```json\n   {\n       \"failNotes\": [\n        \"comments\": \"corrected sugestion\",\n       \"The term we is not alowed.\": \"I think I should go to the store.\",\n]\n       \"modifiedThought\": \"Here goes the full modifiend thougt\",\n       \"severity\": 1\n   }\n   ```\n",
  });
  
  const generationConfig = {
    temperature: 1,
    topP: 0.95,
    topK: 40,
    maxOutputTokens: 8192,
    responseMimeType: "text/plain",
  };
  
  async function run() {
    const chatSession = model.startChat({
      generationConfig,
      history: [
      ],
    });
  
    const result = await chatSession.sendMessage("INSERT_INPUT_HERE");
    console.log(result.response.text());
  }
  
  run();