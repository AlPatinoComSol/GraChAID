# GrAID2 Technical Documentation

## Overview

GrAID2 is a Chrome extension designed to perform grammar checks on user trajectories in the AI Debugger. It utilizes two primary checking mechanisms: a Regex-based checker and the Gemini API. This documentation provides a comprehensive guide on setting up, using, and understanding the functionalities of GrAID2.

## Table of Contents

1. [Installation](#installation)
2. [API Key Setup](#api-key-setup)
3. [Usage](#usage)
4. [Features](#features)
5. [Error Analysis](#error-analysis)
6. [Project Structure](#project-structure)
7. [File Descriptions](#file-descriptions)
8. [Contributing](#contributing)

## Installation

To install GrAID2, follow these steps:

1. Download the latest `.zip` file from the [GrAID2 GitHub repository](https://github.com/AlPatinoComSol/GraChAID).
2. Unzip the file.
3. Open Google Chrome and navigate to the extensions page (`chrome://extensions/`).
4. Enable "Developer mode" in the top right corner.
5. Click on "Load unpacked" and select the unzipped folder.

## API Key Setup

To set up the Gemini API key, follow these steps:

1. Visit the [GEMINI API](https://aistudio.google.com/app/apikey) page.
2. Click on the "Create API key" button.
3. Select a project or create a new one in the [Google Cloud Console](https://console.cloud.google.com/).
4. Generate the API key and copy it.
5. Paste the API key into the `.env` file under the `GEMINI_API_KEY` field.
6. Open `dist/bundle.js` and locate `GoogleGenerativeAI(`. Replace `GEMINI_API_KEY` with your actual API key.
7. Reload the extension from the extensions page.

## Usage

Once installed, you can use GrAID2 by clicking on the extension icon in the Chrome toolbar. A popup will appear, providing access to various functionalities.

### Main Features

- **Grammar Check**: Initiate a grammar check on your trajectory.
- **Review All Turns**: Review all turns in your trajectory for grammar issues.
- **Copy All Turns**: Copy all turns to the clipboard for external use.
- **BeTool Integration**: Access BeTool directly from the extension.

## Features

### Side Panel

When you click on the **Side Panel** button, a side panel will appear on the right side of the screen, displaying:

- **Copy All Turns**: Copies all turns to the clipboard.
- **Review All Turns**: Reviews all turns for grammar issues.
- **BeTool**: Links to the BeTool for further analysis.

### Turn Analysis

Each turn is analyzed for grammar issues, with severity levels indicated by color coding:

- **Green**: No grammar issues.
- **Red**: Grammar issues detected.

### Detailed Turn Information

When a turn is expanded, it displays:

- **Turn Number**
- **Turn ID**
- **Turn Text**: The original thought and action.
- **Errors**: A list of detected errors.
- **Turn Analysis**: Suggestions for improvement.

## Error Analysis

GrAID2 performs a detailed analysis of each turn, checking for:

- Grammar errors
- Missing line numbers in actions
- Unmatched backticks
- Common word usage errors
- Spelling mistakes

The analysis results are returned in a structured format, providing comments and suggested corrections.


## Project Structure

The project structure for GrAID2 is as follows:

```
GrAID2/
│
├── dist/                     # Compiled files
│   └── bundle.js             # Bundled JavaScript file
│
├── node_modules/             # Node.js modules
│
│                             # Source files
├── background.js             # Background script for handling events
├── content.js                # Content script for interacting with web pages
├── popup.js                  # Script for the popup interface
├── sidePanel.js              # Script for the side panel functionality
├── config.js                 # Configuration and common word lists
├── webpack.config.js         # Webpack configuration file
├── popup.css                 # Styles for the popup interface
├── sidePanel.css             # Styles for the side panel interface
├── popup.html                # HTML for the popup interface
├── sidePanel.html            # HTML for the side panel interface
├── .gitignore                 # Files and directories to ignore in Git
├── .env                       # Environment variables
└── package.json               # Project metadata and dependencies
```
## File Descriptions

- **dist/**: This directory contains compiled files that are ready for deployment. The `bundle.js` file is the main JavaScript file that includes all the necessary code for the extension to function.
- **node_modules/****: This directory contains all the Node.js modules that the project depends on. These modules are installed via npm and are essential for the development and functionality of the extension.
- **background.js**: DEPRECATED/Unused. This script runs in the background and handles events such as messages from content scripts. It can manage tasks that do not require direct interaction with the web page.
- **content.js**: This script interacts with web pages, extracting data and performing actions based on user interactions.
- **popup.js**: This script manages the popup interface that appears when the extension icon is clicked. It handles user interactions and displays relevant information.
- **sidePanel.js**: This script manages the functionality of the side panel, including displaying errors and providing options for users to copy or review turns.
- **config.js**: This file contains configuration settings and lists of common words and mistakes used in the analysis process.
- **webpack.config.js**: This file contains the configuration for Webpack, which is used to bundle the JavaScript files and manage dependencies.
- **popup.css**: This file contains the styles for the popup interface, defining the layout, colors, and hover effects for the elements within the popup.
- **sidePanel.css**: This file contains the styles for the side panel interface, including button styles, error message formatting, and overall layout.
- **popup.html**: This file contains the HTML structure for the popup interface.
- **sidePanel.html**: This file contains the HTML structure for the side panel interface.
- **.gitignore**: This file specifies files and directories that should be ignored by Git, such as `node_modules/` and `.env`.
- **.env**: This file contains environment variables, including sensitive information like API keys that should not be shared publicly.
- **package.json**: This file contains metadata about the project, including its dependencies, scripts for building and developing the project, and other configuration settings.

## Detailed Descriptions of JavaScript Files

### Detailed Description of `content.js`

The `content.js` file is a crucial component of the GrAID2 Chrome extension, responsible for interacting with the web page's content to extract relevant data related to user turns. Below is an elaboration on the detailed description of `content.js`, highlighting its key functionalities and structure:

- **Purpose**: The primary role of `content.js` is to extract data from the web page where the GrAID2 extension is active. This data includes user turns, email content, run outcomes, and notes, which are essential for performing grammar checks and providing feedback to the user.

- **Key Functions**:
  1. **`extractTurnsData()`**: 
     - This function gathers comprehensive data about user turns. It initializes an object to hold the extracted data, including turns, email content, run status, and notes.
     - It uses DOM manipulation to select specific elements on the page, such as the email header and paragraphs containing run status and notes.
     - The function iterates through the turns displayed on the page, extracting relevant information such as thoughts, actions, IDs, and metadata (e.g., status, time, and whether the turn has been edited).
     - The extracted data is structured in a way that can be easily sent to the background script for further processing.

  2. **`extractTurnsIDs()`**: 
     - This function focuses specifically on extracting the IDs of the turns. It follows a similar approach to `extractTurnsData()`, selecting the relevant elements and iterating through them to collect IDs.
     - The extracted IDs are returned in a structured format, allowing for easy access and manipulation.

  3. **`checkGrammar()`**: 
     - This function serves as a bridge between the extracted data and the grammar checking process. It calls `extractTurnsData()` to gather the necessary information and sends it to the background script using `chrome.runtime.sendMessage()`.
     - This function is triggered when the user clicks the "Next" button, indicating that they want to check the grammar of the current turn.

  4. **`UpdateTurns()`**: 
     - Similar to `checkGrammar()`, this function extracts turn IDs and sends them to the background script. It is called when the user clicks the "Revert" button, allowing for updates to the current state of turns.

- **Event Listeners**:
  - The script listens for click events on the document to determine if the user has clicked the "Next" or "Revert" buttons. Depending on the button clicked, it either checks grammar or updates the turns.
  - Additionally, it listens for messages from the background script, allowing it to respond to specific actions such as scrolling to a particular element on the page or reviewing all turns.

- **DOM Manipulation**:
  - The script heavily relies on the Document Object Model (DOM) to select and manipulate elements on the page. It uses methods like `querySelector` and `querySelectorAll` to find elements based on their class names and other attributes.
  - The extracted data is formatted and structured to ensure it can be easily processed and displayed in the extension's UI.

- **Data Structure**:
  - The data extracted by `content.js` is organized into objects and arrays, making it easy to handle and send to other parts of the extension. For example, the `data` object in `extractTurnsData()` contains an array of turns, each represented as an object with properties for thoughts, actions, metadata, etc.

- **Integration with Chrome APIs**:
  - The script utilizes the Chrome Extensions API, specifically `chrome.runtime.sendMessage()`, to communicate with the background script. This allows for seamless interaction between the content script and other components of the extension.

Overall, `content.js` plays a vital role in the GrAID2 extension by extracting and processing user data from the web page, enabling the extension to provide grammar checking and analysis functionalities effectively.


### Detailed Description of `popup.js`

The `popup.js` file is an integral part of the GrAID2 Chrome extension, responsible for managing the user interface of the popup that appears when the extension icon is clicked. This file handles the initialization of local storage, user interactions, and communication with the side panel of the browser. Below is a detailed breakdown of its key functionalities and structure:

- **Purpose**: The primary role of `popup.js` is to provide a user-friendly interface for interacting with the GrAID2 extension. It initializes default instructions for the intelligent agent, manages user actions, and facilitates communication between the popup and the side panel.

- **Key Functions**:
  1. **`initializeLocalStorage()`**: 
     - This function sets up the local storage with default instructions for the intelligent agent if they are not already present. The instructions outline the criteria for analyzing user turns, including guidelines for thoughts and actions, severity ratings, and the expected output format.
     - The default instructions are comprehensive, detailing the requirements for clarity, grammar, and structure, ensuring that the intelligent agent has a clear understanding of its tasks.
     - If the instructions are already set in local storage, the function logs a message indicating that no changes are necessary.

  2. **Event Listeners**:
     - The script listens for the `DOMContentLoaded` event to ensure that the browser's side panel is ready before proceeding with any actions.
     - An event listener is attached to the "Check Grammar" button, which, when clicked, fetches the `sidePanel.html` content and opens it in the browser's side panel. This action also closes the popup to streamline the user experience.
     - Additional event listeners are set up for navigation links within the popup, allowing users to open links in new tabs without disrupting the current popup interface.

- **Side Panel Management**:
  - The function `isSidePanelAvailable()` checks if the browser supports the side panel API, ensuring that the extension can interact with the side panel effectively.
  - The `openBrowserSidePanel(content)` function manages the opening of the side panel. It retrieves the active tab ID and sets the side panel options, including the path to the `sidePanel.html` file. If the side panel API is not available, it logs an error message.

- **User Interaction**:
  - The popup interface is designed to be intuitive, allowing users to easily access the grammar checking functionality and navigate to relevant resources, such as the GitHub repository.
  - The use of event listeners enhances user interaction by providing immediate feedback and actions based on user inputs.

- **Integration with Chrome APIs**:
  - The script utilizes various Chrome APIs, including `chrome.tabs` and `chrome.sidePanel`, to manage the extension's behavior and ensure seamless communication between the popup and the side panel.
  - The integration with the side panel allows for a more immersive user experience, enabling users to view analysis results and interact with the extension without leaving the current page.

Overall, `popup.js` plays a vital role in the GrAID2 extension by providing a user-friendly interface, managing local storage, and facilitating communication with the side panel. Its design ensures that users can efficiently access grammar checking functionalities and receive guidance on their user turns.

### Detailed Description of `sidePanel.js`

The `sidePanel.js` file is a key component of the GrAID2 Chrome extension, responsible for managing the side panel interface that displays analysis results, errors, and options for users to interact with their turns. This file integrates various functionalities, including spell checking, grammar analysis using the Gemini API, and user interaction with the side panel. Below is a detailed breakdown of its key functionalities and structure:

- **Purpose**: The primary role of `sidePanel.js` is to provide a comprehensive analysis of user turns, highlighting errors and offering suggestions for improvement. It utilizes the Gemini API for advanced analysis and integrates a spell-checking library to ensure the accuracy of the text.

- **Key Components**:
  1. **Dependencies**:
     - The file imports the `Typo` library for spell checking and the `GoogleGenerativeAI` class from the Gemini API package. This allows the extension to perform grammar checks and provide intelligent feedback on user inputs.

  2. **Initialization**:
     - The script initializes a dictionary for spell checking using the `Typo` library and sets up the Gemini API with the provided API key and system instructions stored in local storage. If the initialization fails, it logs an error and sets the `genAI` and `model` variables to `null`.

  3. **Error Handling**:
     - The `getReadableErrorMessage` function provides user-friendly error messages based on specific error types encountered during analysis. This function maps error types to descriptive titles and messages, enhancing the user experience by clearly communicating issues.

  4. **Analysis Functions**:
     - **`analyzeWithGemini(turn)`**: This asynchronous function sends a turn's thought and action to the Gemini API for analysis. It constructs a prompt, sends it to the API, and processes the response to extract the analysis results. If an error occurs during the analysis, it logs the error and returns `null`.
     - **`analyzeTurn(turn)`**: This function orchestrates the analysis process by performing regular analysis and, if specified, invoking the Gemini analysis. It combines the results from both analyses and returns a comprehensive analysis object.

  5. **Turn Management**:
     - **`addTurn(turnNumber, turn, analysisResults)`**: This function adds a turn's analysis results to the side panel. It creates a list item for each turn, displaying relevant information, error messages, and suggestions. The background color of the list item changes based on the presence of errors, providing visual feedback to the user.
     - The function also includes interactive elements, such as buttons for toggling error visibility and copying turn text to the clipboard.

  6. **User Interaction**:
     - The side panel includes buttons for copying all turn texts and reviewing all turns. The `showPopup` function displays temporary notifications to inform users of successful actions, such as copying text.
     - The script listens for messages from the content script, allowing it to update the displayed turns based on user interactions and the current state of the analysis.

  7. **Error Analysis**:
     - The `performRegularAnalysis(turn)` function conducts a series of checks on the turn's thought and action, identifying common errors such as unmatched backticks, missing periods, and spelling mistakes. It utilizes regular expressions to detect specific patterns and maintains a structured format for reporting errors.

  8. **Spell Checking**:
     - The `checkMisspelledWords(thought)` function processes the turn's thought to identify misspelled words, excluding exceptions and words within backticks. It uses the `Typo` library to check each word against a dictionary and returns a list of misspelled words along with suggested corrections.

Overall, `sidePanel.js` plays a vital role in the GrAID2 extension by providing a robust interface for analyzing user turns, highlighting errors, and offering actionable feedback. Its integration with the Gemini API and spell-checking functionality enhances the extension's capabilities, making it a valuable tool for users seeking to improve their grammar and clarity in communication.

### Detailed Description of `config.js`

The `config.js` file serves as a configuration module for the GrAID2 Chrome extension, providing essential data structures and regular expressions that facilitate the analysis of user turns. This file contains lists of common word mistakes, command-line words, exceptions for the spell checker, and regular expression patterns for identifying various naming conventions. Below is a detailed breakdown of its key components:

- **Common Word Mistakes**:
  - The `WORD_MISTAKES` array contains a list of phrases that are frequently misused in writing. These phrases often lead to grammatical errors or confusion in communication. By identifying these common mistakes, the extension can provide targeted feedback to users, helping them improve their writing clarity and correctness.

- **Common Command-Line Words**:
  - The `COMMON_WORDS` array includes a comprehensive list of command-line commands and tools that are commonly used in programming and system administration. This list helps the extension recognize technical terms that users may include in their turns, ensuring that these terms are not flagged as errors during analysis.

- **Spell Checker Exceptions**:
  - The `WORD_EXCEPTIONS_SPELL_CHECKER` set contains words and phrases that should not be flagged by the spell checker, even if they are not found in standard dictionaries. This includes contractions, technical terms, and programming-related jargon. By maintaining this set, the extension can avoid false positives in spell checking, allowing users to write more naturally without unnecessary corrections.

- **Regular Expression Patterns**:
  - The file defines several regular expression patterns that are used to identify specific naming conventions within the text:
    - **`CAMELCASE_PATTERN`**: This pattern matches camelCase words, which are commonly used in programming for variable and function names.
    - **`UPPERCASE_PATTERN`**: This pattern matches UPPER_CASE words, typically used for constants or specific identifiers in code.
    - **`SNAKECASE_PATTERN`**: This pattern matches snake_case words, another common naming convention in programming.
    - **`PATH_PATTERN`**: This pattern matches file paths, which are often included in user turns when discussing file management or directory structures.

### Summary

Overall, `config.js` plays a vital role in the GrAID2 extension by providing the necessary configurations and data structures that support the analysis of user turns. By defining common mistakes, exceptions, and regular expression patterns, this file enhances the extension's ability to deliver accurate and relevant feedback to users, ultimately improving their writing and communication skills in technical contexts.


### Detailed Description of `webpack.config.js`

The `webpack.config.js` file is a configuration file for Webpack, a powerful module bundler used to compile and bundle JavaScript files and other assets for the GrAID2 Chrome extension. This file defines how the application is built, specifying entry points, output settings, module rules, and plugins. Below is a detailed breakdown of its key components:

- **Entry Point**:
  - The `entry` property specifies the main file that Webpack will use as the starting point for building the dependency graph. In this case, it is set to `./sidePanel.js`, indicating that this file is the primary module from which the application will begin bundling.

- **Output Configuration**:
  - The `output` property defines how and where the bundled files will be generated. 
    - `filename`: This specifies the name of the output file, which is set to `bundle.js`. This is the file that will be generated in the `dist` directory.
    - `path`: This specifies the output directory for the bundled file. It uses `path.resolve(__dirname, 'dist')` to create an absolute path to the `dist` folder within the current directory.

- **Mode**:
  - The `mode` property is set to `'development'`, which enables Webpack's development mode. This mode provides useful debugging features, such as more detailed error messages and source maps, which help developers during the development process.

- **Source Maps**:
  - The `devtool` property is set to `'source-map'`, which generates source maps for the bundled code. Source maps allow developers to debug their original source code in the browser's developer tools, making it easier to trace errors back to the original files.

- **Module Rules**:
  - The `module` property contains rules that define how different types of files should be processed. In this configuration:
    - A rule is defined for JavaScript files (`test: /\.js$/`), which tells Webpack to apply the specified loader to all `.js` files.
    - The `exclude` property is used to ignore files in the `node_modules` directory, as these are typically pre-compiled and do not need to be processed by Babel.
    - The `use` property specifies that the `babel-loader` should be used to transpile the JavaScript files. The `options` property includes the `presets` array, which specifies that the `@babel/preset-env` preset should be used. This preset allows the use of the latest JavaScript features while ensuring compatibility with older browsers.

- **Plugins**:
  - The `plugins` property is an array that contains instances of Webpack plugins that enhance the build process. In this configuration:
    - The `DefinePlugin` is used to create global constants that can be configured at compile time. This is particularly useful for injecting environment variables into the code. The plugin is configured to define three environment variables:
      - `process.env.GEMINI_API_KEY`: This variable holds the API key for the Gemini API.
      - `process.env.PREFERED_MODEL`: This variable specifies the preferred model for analysis (e.g., Gemini or GPT).
      - `process.env.GPT_API_KEY`: This variable holds the API key for the GPT model.

### Summary

Overall, `webpack.config.js` is a crucial file for the GrAID2 Chrome extension, as it configures Webpack to bundle the JavaScript files and manage dependencies effectively. By defining entry points, output settings, module rules, and plugins, this configuration file ensures that the extension is built correctly and efficiently, allowing developers to leverage modern JavaScript features while maintaining compatibility with various environments.

## Updating Files

After making changes to the files, you need to compile the changes and reload the extension.

1. Open the file to be updated.
2. Make the necessary changes to the code.
3. Save the file.
4. Run the `npx webpack` command to compile the changes.
5. Reload the extension from the extensions page.

**Note**: the command `npx webpack` compiles all the files in the project, including the `.env` file. Therefore, the API keys from `.env` are included in the compiled `bundle.js` file.

Please note that the `npx webpack` command is used to compile the changes. If you are using a different package manager, you may need to use the appropriate command to compile the changes.
Also, if you are using a different version of Node.js, you may need to use the appropriate command to compile the changes.



## Contributing

Contributions to GrAID2 are welcome! If you have suggestions for improvements or new features, please feel free to submit a pull request or open an issue on the GitHub repository.


---

For further information, please refer to the [GrAID2 GitHub repository](https://github.com/AlPatinoComSol/GraChAID).
