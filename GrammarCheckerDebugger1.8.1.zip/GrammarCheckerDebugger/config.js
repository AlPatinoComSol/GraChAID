// List of common word mistakes often made in writing
const WORD_MISTAKES = [
    "let's",
    "lets",
    "let us",
    "we'll",
    "we're",
    "we've",
    "we will",
    "we are",
    "we have",
    "our",
    "ourselves",
    "you'll",
    "you're",
    "your",
    "yourselves",
    "you are",
    "you will",
    "they'll",
    "they're",
    "they've",
    "they will",
    "they are",
    "they have",
    "their",
    "theirs",
    "themselves",
    "all of us",
    "among us",
    "between us",
    "both of us",
    "together we",
    "together with us",
    "you've",
    "we'd",
    "they'd",
    "who'll",
    "who're",
    "who've",
    "what'll",
    "what're",
    "what've",
    "that'll",
    "that're"
];

// List of common command-line words and tools
const COMMON_WORDS = [
    "ls", "cd", "mkdir", "rm", "cp", "mv", "chmod", "chown", "grep", "sed", 
    "awk", "curl", "wget", "scp", "ssh", "tar", "zip", "unzip", "apt", 
    "apt-get", "yum", "dnf", "brew", "pacman", "snap", "pip", "pip3", 
    "npm", "yarn", "npx", "git", "git-clone", "git-pull", "git-push", 
    "git-commit", "git-status", "git-checkout", "git-merge", "git-rebase", 
    "docker", "kubectl", "helm", "terraform", "ansible", "vagrant", "gcc", 
    "g++", "clang", "javac", "mvn", "gradle", "composer", "gem", "rails", 
    "rake", "rustc", "cargo", "dotnet", "msbuild", "zsh", "tmux", 
    "htop", "ps", "kill", "killall", "pkill", "systemctl", "journalctl", 
    "rsync", "openssl", "keytool", "certutil", "jq", "xargs", "tee", 
    "diff", "uniq", "basename", "dirname", "whereis", "vmstat", 
    "iostat", "netstat", "ss", "traceroute", "nslookup", "dig", "ifconfig", 
    "iptables", "firewalld", "nmap", "telnet", "nc", "mysql", "psql", 
    "mongo", "redis-cli", "sqlite3", "vault", "consul", "etcd", "minikube", 
    "podman",
    "docker-compose",
    "kube",
    "k8s",
    "npm-install",
    "npm-run"
];

// Set of exceptions for the spell checker that should not be flagged
const WORD_EXCEPTIONS_SPELL_CHECKER = new Set([
    "I'll", "I've", "I'm", "it'll", "isn't", "don't", "can't", "you're", "I'd",
    "we're", "they're", "it's", "doesn't", "didn't", "wouldn't", "couldn't",
    "shouldn't", "aren't", "weren't", "hasn't", "haven't", "won't", "what's",
    "who's", "there's", "that's", "let's", "html", "metadata", "HTML", "codebase",
    "docstring", "boolean", "url", "urls", "api", "github", "xss", "javascript",
    "app", "apps", "frontend", "backend", "frontend", "backend", "frontend",
    "won't", "doesn't", "can't", "isn't", "aren't", "wasn't", "haven't",
    "hasn't", "don't", "hardcoded",
    "shouldn't",
    "couldn't",
    "wouldn't",
    "CSS",
    "JSON",
    "API",
    "URL",
    "HTTP",
    "HTTPS"
]);

// Regular expression patterns for different naming conventions
const CAMELCASE_PATTERN = new RegExp('\\b[a-z]+[A-Z][a-zA-Z]*\\b', 'g'); // Matches camelCase
const UPPERCASE_PATTERN = new RegExp('\\b[A-Z]{2,}(?:_[A-Z]+)*\\b(?!\\.\\w+)', 'g'); // Matches UPPER_CASE
const SNAKECASE_PATTERN = new RegExp('\\b[a-zA-Z0-9]+(?:_+[a-zA-Z0-9]+)+\\b', 'g'); // Matches snake_case
const PATH_PATTERN = new RegExp('/?(?:[a-zA-Z0-9_\\-\\.]+/)+[a-zA-Z0-9_\\-\\.]+', 'g'); // Matches file paths

