// content.js

// Function to extract turns data
function extractTurnsData() {
    var data = {
        turns: [],
    };

    // Select the email header element
    const emailDiv = document.querySelector('h1.m_8a5d1357.mantine-Title-root');
    if (emailDiv) {
        // Extract email content from the header
        const match = emailDiv.textContent.match(/\((.*?)\)/);
        const emailDivContent = match ? match[1] : null;
        data.email = emailDivContent;
    }

    // Check if the run has stopped and extract the outcome
    const runStopped = Array.from(document.querySelectorAll('p.mantine-focus-auto.m_b6d8b162.mantine-Text-root'))
        .find(p => p.textContent.includes('Run stopped'));
    if (runStopped) {
        const outcomeMatch = runStopped.textContent.match(/\((.*?)\)/);
        const outcome = outcomeMatch ? outcomeMatch[1] : null;
        data.run = {
            run_stopped: true,
            outcome: outcome
        };
    } else {
        data.run = { run_stopped: false };
    }

    // Extract notes if available
    const notes = Array.from(document.querySelectorAll('p.mantine-focus-auto.m_b6d8b162.mantine-Text-root'))
        .find(p => p.textContent.includes('Notes:'));
    if (notes) {
        const notesText = notes.textContent.trim().replace('Notes:', '').trim();
        data.notes = notesText;
    } else {
        data.notes = null;
    }
    
    // Select the wrapper for turns data
    const turnsWrapperDiv = document.querySelector('div.m_8bffd616.mantine-Flex-root.__m__-rd');
    if (turnsWrapperDiv) {
        const turnsDiv = turnsWrapperDiv.querySelectorAll('div.mantine-Card-root.m_1b7284a3.mantine-Paper-root');
        let turnNumber = 1;

        // Iterate through each turn and extract relevant data
        turnsDiv.forEach(turnDiv => { 
            var turn = {};
            const thoughtElements = turnDiv.querySelectorAll('.m_6d731127 > .m_6d731127 p');
            turn.thoughts_p = Array.from(thoughtElements).map(p => p.innerHTML); // Extract <p> contents
            turn.thought_backup = turn.thoughts_p.join('\n');
            turn.thought = turn.thought_backup.replace(/<code>/g, '`').replace(/<\/code>/g, '`');
            turn.thought_html = turn.thought_backup.replace(/<code>/g, '<code>`').replace(/<\/code>/g, '`</code>');
            turn.action = turnDiv.querySelector('pre.m_b183c0a2').innerHTML; // Extract action content
            turn.ID = turnDiv.querySelector('div.m_599a2148.mantine-Card-section p').innerHTML; // Extract id

            // Extract metadata for each turn
            const svgTag = turnDiv.querySelector('svg[stroke]');
            const strokeValue = svgTag ? svgTag.getAttribute('stroke') : '';
            turn.metadata = {
                turn_number: turnNumber,
                message: turnDiv.querySelector('p.mantine-focus-auto.m_b6d8b162.mantine-Text-root').innerText.trim(),
                status_message: strokeValue.includes('green') ? 'success' : strokeValue.includes('red') ? 'fail' : 'not run',
                status: strokeValue.includes('green') ? true : strokeValue.includes('red') ? false : null,
                time: turnDiv.querySelector('p.mantine-focus-auto.m_b6d8b162.mantine-Text-root[data-size="xs"]').innerText.trim().split('(').pop().trim().slice(0, -1),
                mark_as_incorrect: turnDiv.querySelector('input.mantine-focus-auto.m_26063560.mantine-Checkbox-input').checked,
                edited: turnDiv.querySelector('svg.tabler-icon.tabler-icon-caret-left') !== null
            };
            data.turns.push(turn);
            turnNumber++;
        });
    }
    return data; // Return the extracted data
}

function extractTurnsIDs(){
    var data = {
        turns: [],
    };
    
    // Select the wrapper for turns IDs
    const turnsWrapperDiv = document.querySelector('div.m_8bffd616.mantine-Flex-root.__m__-rd');
    if (turnsWrapperDiv) {
        const turnsDiv = turnsWrapperDiv.querySelectorAll('div.mantine-Card-root.m_1b7284a3.mantine-Paper-root');
        let turnNumber = 1;

        // Iterate through each turn and extract IDs
        turnsDiv.forEach(turnDiv => { 
            var turn = {};
            turn.ID = turnDiv.querySelector('div.m_599a2148.mantine-Card-section p').innerHTML; // Extract id
            data.turns.push(turn);
            turnNumber++;
        });
    }
    return data; // Return the extracted IDs
}

// Function to extract paragraphs and send to grammar checker
function checkGrammar() {
    var data = extractTurnsData(); // Extract turns data
    chrome.runtime.sendMessage({ data: data }); // Send extracted data
}

function UpdateTurns(){
    var data = extractTurnsIDs(); // Extract turns IDs
    chrome.runtime.sendMessage({ IDS: data }); // Send extracted IDs
}   

// Listen for the "Next" button click
document.addEventListener('click', function(event) {
    // Check if the clicked element is the "Next" button
    if ((event.target.classList.contains('mantine-Button-root') 
        || event.target.classList.contains('mantine-Button-inner')
    || event.target.classList.contains('mantine-UnstyledButton-root')
    || event.target.classList.contains('mantine-Button-section')
    || event.target.classList.contains('mantine-Button-label')) && event.target.innerText.trim() === 'Next') {
        checkGrammar(); // Check grammar on button click
    } else if ((event.target.classList.contains('mantine-Button-root') 
        || event.target.classList.contains('mantine-Button-inner')
        || event.target.classList.contains('mantine-UnstyledButton-root')
        || event.target.classList.contains('mantine-Button-section')
        || event.target.classList.contains('mantine-Button-label')) && event.target.innerText.trim() === 'Revert') {
        UpdateTurns(); // Update turns on button click
    }
});

// Update the message listener to search for the element by text content
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'scrollToElement') {
        // Find the paragraph containing the ID text
        const elements = document.querySelectorAll('p.mantine-focus-auto.m_b6d8b162.mantine-Text-root');
        const targetElement = Array.from(elements).find(el => el.textContent.includes(request.elementId));
        
        if (targetElement) {
            // Find the parent card element for better visibility
            const cardElement = targetElement.closest('.mantine-Card-root');
            if (cardElement) {
                cardElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                // Add highlight effect to the card
                cardElement.style.transition = 'background-color 0.5s';
                cardElement.style.backgroundColor = '#fff3cd';
                setTimeout(() => {
                    cardElement.style.backgroundColor = '';
                }, 2000);
            }
        }
    } else if (request.action === 'reviewAllTurns') {
        console.log('Reviewing all turns');
        var data = extractTurnsData(); // Extract turns data
        
        chrome.runtime.sendMessage({ data: data }); // Send extracted data
    }
});

