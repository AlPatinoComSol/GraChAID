// background.js

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "checkGrammar") {
        // Here you can handle the grammar checking logic if needed
        // For now, we will just send a response back
        sendResponse({ status: "Grammar check initiated" });
    }
});