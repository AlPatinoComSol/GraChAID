/*
import { 
    WORD_MISTAKES, 
    CAMELCASE_PATTERN, 
    SNAKECASE_PATTERN, 
    PATH_PATTERN, 
    UPPERCASE_PATTERN, 
    COMMON_WORDS, 
    WORD_EXCEPTIONS_SPELL_CHECKER 
} from './config.js';
*/
import Typo from 'typo-js';
import { GoogleGenerativeAI } from "@google/generative-ai";

var dictionary = new Typo("en_US", false, false, { dictionaryPath: "/node_modules/typo-js/dictionaries" });

// Initialize Gemini with the API key
var genAI = null;
var model = null;
try{
    genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

    model = genAI.getGenerativeModel({
        model: "gemini-1.5-flash",
        systemInstruction: "You are an intelligent agent that receives a JSON object representing a single turn. This turn contains a `thought` and an `action`. Your task is to analyze the turn according to the following requirements and return a JSON object with comments, corrections for any issues found, and a suggested modified thought:\n\n1. **Thought criteria**: \n   - The `thought` must be free of grammar errors and should always aim to improve clarity and flow.\n   - The `thought` should be written in the first person singular and in the present tense and future simple tense.\n   - The `thought` must not mention other people (e.g., \"you,\" \"we,\" etc.).\n   - The `thought` must end with a period ('.') and never with a colon (':') or question mark ('?').\n   - If a particular string is mentioned in the `thought`, it should be enclosed in double quotes ('\"').\n   - If a code-related term, file name, directory name, command line, library names, package names, error types, variable names, method names, classes, or anything related to code is mentioned, it should be enclosed in backticks ('`').\n   - It is acceptable if the thought contains explanations about the thought.\n\n2. **Action criteria**: \n   - Ensure that the action corresponds to the thought.\n   - If the action contains edit or goto commands with line numbers, those line numbers must be mentioned in the `thought`. If they are missing, label it as \"missing pointers.\".\n   - If the action is unclear or does not match the thought, provide a comment indicating the discrepancy.\n\n3. **Severity Rating**: Rate the turn with a severity level:\n   - 0: No modifications\n   - 1: Some modifications\n\n4. **Output Format**: Return the modified JSON object with a `failNotes` array that contains the comment of each fail as a key and the suggested correction as a value; the `failNotes` should only include comments with issues; the good things are not supposed to be mentioned.\n   - `severity`: An integer (0 or 1) representing the severity rating.\n   - `suggestedThought`: The full thought with the proper modifications to make it free of grammar errors, with clarity and flow improved, no redundancy, aligned with the action and the `thought` criteria. \n   **Example Output Structure**:\n   ```json\n   {\n       \"failNotes\": [\n        \"comments\": \"recomended sugestion\",\n       \"The term we is not alowed.\"You should user first person In all sentences\",\n]\n       \"suggestedThought\": \"Here goes the full modified thougth\",\n       \"severity\": 1\n   }\n   ```\n",
        });
}catch(error){
    genAI = null;
    model = null;
}

function getReadableErrorMessage(errorType, error) {
    const errorMessages = {
        error_word_mistakes: {
            title: "Word Usage Error",
            description: word => `The word "${word}" might be inappropriate or incorrect in this context.`
        },
        error_no_ends_with_dot: {
            title: "Missing Period",
            description: "The thought should end with a period (.)"
        },
        error_edit_numbers_not_in_thought: {
            title: "Missing Line Numbers",
            description: "The edit line numbers should be mentioned in the thought."
        },
        error_unmatched_backticks: {
            title: "Unmatched Code Markers",
            description: "There are unmatched backticks (`) in the text. Code snippets should be wrapped in pairs of backticks."
        },
        error_uppercase_no_backticks: {
            title: "Unmarked Code (Uppercase)",
            description: word => `The uppercase term "${word}" should be wrapped in backticks.`
        },
        error_common_word_no_backticks: {
            title: "Unmarked Technical Term",
            description: word => `The technical term "${word}" should be wrapped in backticks.`
        },
        error_snakecase_no_backticks: {
            title: "Unmarked Code (Snake Case)",
            description: word => `The snake_case term "${word}" should be wrapped in backticks.`
        },
        error_path_no_backticks: {
            title: "Unmarked File Path",
            description: path => `The file path "${path}" should be wrapped in backticks.`
        },
        error_spell_checker: {
            title: "Possible Spelling Error",
            description: (word, suggestion) => `"${word}" might be misspelled${suggestion ? `. Did you mean "${suggestion}"?` : '.'}`
        },
        error_not_submit_action: {
            title: "Incomplete Submit Action",
            description: "The submit action was not completed successfully."
        }
    };

    return errorMessages[errorType] || { 
        title: "Unknown Error",
        description: "An unspecified error occurred."
    };
}

function checkMisspelledWords(thought) {
    // Process text to remove words between backticks and punctuation
    const thoughtWithoutBacktickWords = thought.replace(/`[^`]*`/g, '').split(/\s+/);
    const punctuationToRemove = /[^\w\s]|_|[.,:;\\`]/g; // Updated regex to remove additional punctuation

    // First filter out words in WORD_EXCEPTIONS_SPELL_CHECKER, then remove punctuation
    const filteredWords = thoughtWithoutBacktickWords
        .filter(word => word && !WORD_EXCEPTIONS_SPELL_CHECKER.has(word)) // Filter out exceptions first
        .map(word => word.replace(punctuationToRemove, '')); // Then remove punctuation

    // Evaluate filtered words against the dictionary for misspellings
    const misspelledWords = filteredWords.filter(word => !dictionary.check(word)); // Check each word against the dictionary

    return misspelledWords; // Return only the misspelled words
}

async function analyzeWithGemini(turn) {
    try {
        const chatSession = model.startChat({
            generationConfig: {
                temperature: 1,
                topP: 0.95,
                topK: 40,
                maxOutputTokens: 8192,
            },
        });

        const prompt = JSON.stringify({
            thought: turn.thought,
            action: turn.action
        });
        
        //console.log(prompt);

        const result = await chatSession.sendMessage(prompt);
        try {
            const analysis = JSON.parse(result.response.candidates[0].content.parts[0].text.replace(/```json\n/, '').replace(/\n```/, ''));    
            //console.log(analysis);
            return analysis;
        } catch (error) {
            console.error('Error analyzing with Gemini:', error);
            return null;
        }
    } catch (error) {
        console.error('Error analyzing with Gemini:', error);
        return null;
    }
}

// Function to add a turn to the sidebar
function addTurn(turnNumber, turn, analysisResults) {
    const errorList = document.getElementById('errorList');
    
    // Create a list item for the turn
    const listItem = document.createElement('li');
    listItem.id = turn.ID; // Add the ID to the list item
    var geminiAnalysis = null;
    try{
        geminiAnalysis = analysisResults.geminiAnalysis;
    }catch(error){analysisResults
        geminiAnalysis = null
    }
    // Set background color based on the presence of errors
    if (Object.keys(analysisResults.analysis.errors).length > 0 || geminiAnalysis.severity > 0) { 
        listItem.style.backgroundColor = 'rgba(255, 0, 0, 0.3)';
    } else {
        listItem.style.backgroundColor = 'rgba(0, 255, 0, 0.3)';
    }

    // Create a container for the header content (turn info and button)
    const headerContainer = document.createElement('div');
    headerContainer.className = 'turn-header';

    // Create a div to hold the visible content
    const visibleContent = document.createElement('div');
    visibleContent.innerHTML = `<strong>#</strong> ${turnNumber} - <strong>ID:</strong> <a href="#" class="id-link">${turn.ID}</a>`;

    // Add click handler for the ID link
    const idLink = visibleContent.querySelector('.id-link');
    idLink.onclick = function(e) {
        e.preventDefault();
        e.stopPropagation();
        // Send message to content script to scroll to this ID
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {
                action: 'scrollToElement',
                elementId: turn.ID
            });
        });
    };

    // Create toggle button
    const toggleButton = document.createElement('button');
    toggleButton.className = 'toggle-button';
    toggleButton.innerHTML = '<i class="fas fa-chevron-down"></i>';

    // Create copy button
    const copyButton = document.createElement('button');
    copyButton.className = 'copy-button';
    copyButton.innerHTML = '<i class="fas fa-copy"></i>';
    copyButton.style.display = 'none'; // Initially hidden
    
    // Create button container
    const buttonContainer = document.createElement('div');
    buttonContainer.className = 'button-container';
    buttonContainer.appendChild(copyButton);
    buttonContainer.appendChild(toggleButton);

    // Add visible content and buttons to header container
    headerContainer.appendChild(visibleContent);
    headerContainer.appendChild(buttonContainer);

    // Create a div to hold the errors (initially hidden)
    const errorContent = document.createElement('div');
    errorContent.className = 'error-content';
    errorContent.style.display = 'none';

    // Build error messages line by line with better formatting
    let errorMessages = [];
    for (const errorType in analysisResults.analysis.errors) {
        const errorValue = analysisResults.analysis.errors[errorType];
        const errorInfo = getReadableErrorMessage(errorType);
        
        if (Array.isArray(errorValue)) {
            if (errorType === 'error_spell_checker') {
                errorValue.forEach(errorObj => {
                    errorMessages.push(`
                        <div class="error-item">
                            <div class="error-title">${errorInfo.title}</div>
                            <div class="error-description">
                                ${errorInfo.description(errorObj.error, errorObj.correction_candidate)}
                            </div>
                        </div>
                    `);
                });
            } else {
                errorValue.forEach(error => {
                    errorMessages.push(`
                        <div class="error-item">
                            <div class="error-title">${errorInfo.title}</div>
                            <div class="error-description">
                                ${errorInfo.description(error)}
                            </div>
                        </div>
                    `);
                });
            }
        } else {
            errorMessages.push(`
                <div class="error-item">
                    <div class="error-title">${errorInfo.title}</div>
                    <div class="error-description">
                        ${errorInfo.description}
                    </div>
                </div>
            `);
        }
    }
    
    //console.log(geminiAnalysis);   
    // Add Gemini analysis if available
    if (geminiAnalysis) {
    if (geminiAnalysis.severity > 0) {
        if (geminiAnalysis.failNotes && Object.keys(geminiAnalysis.failNotes).length > 0) {
            errorMessages.push(`
                <div class="error-item gemini-error">
                    <div class="error-title">Turn Analysis</div>
                    <div class="error-description">
                        <div class="severity-indicator severity-${geminiAnalysis.severity}">
                            Severity: ${geminiAnalysis.severity}
                        </div>
                        <div class="fail-notes">
                            ${Object.entries(geminiAnalysis.failNotes).map(([key, comment]) => `
                                <div class="fail-note">
                                    <div class="note-comment">${key}</div>
                                    <div class="note-suggestion">${comment}</div>
                                </div>
                            `).join('')}
                        </div>
                        ${geminiAnalysis.suggestedThought ? `
                            <div class="suggested-thought-header">
                                <strong>Suggested Thought:</strong>
                            </div>
    
                            <div class="suggestion-text" style="display: inline;">
                                ${geminiAnalysis.suggestedThought}
                            </div>
                               
                        ` : ''}
                    </div>
                </div>
            `);
        }
        }
    }

    errorContent.innerHTML = `
        <strong>Turn Text:</strong>
        <div class="turn-text">
            <div class="text-content">
                ${turn.thought_html}
                ${turn.action ? `<div class="action-text">\`\`\`\n${turn.action}\n\`\`\`</div>` : ''}
            </div>
        </div>
        <div class="errors-section">
            <strong>Errors Found:</strong>
            <div class="errors-list">
                ${errorMessages.join('')}
            </div>
        </div>
    `;

    // Append header container and error content to the list item
    listItem.appendChild(headerContainer);
    listItem.appendChild(errorContent);
    
    // Update toggle button click handler
    toggleButton.onclick = function(e) {
        e.stopPropagation();
        const isExpanding = errorContent.style.display === 'none';
        errorContent.style.display = isExpanding ? 'block' : 'none';
        toggleButton.innerHTML = isExpanding ? 
            '<i class="fas fa-chevron-up"></i>' : 
            '<i class="fas fa-chevron-down"></i>';
        copyButton.style.display = isExpanding ? 'flex' : 'none';
    };

    // Add copy button click handler
    copyButton.onclick = function(e) {
        e.stopPropagation();
        // Get the thought text and replace <code> tags with backticks
        let thoughtText = turn.thought_backup.replace(/<code>/g, '`').replace(/<\/code>/g, '`');
        
        const textToCopy = `${thoughtText}${turn.action ? `\n\n\`\`\`\n${turn.action}\n\`\`\`` : ''}`;
        
        navigator.clipboard.writeText(textToCopy).then(() => {
            // Show feedback
            const originalIcon = copyButton.innerHTML;
            copyButton.innerHTML = '<i class="fas fa-check"></i>';
            setTimeout(() => {
                copyButton.innerHTML = originalIcon;
            }, 1500);
        });
    };

    // Remove the click event from the list item itself
    listItem.onclick = null;

    // Append the list item to the error list
    errorList.appendChild(listItem);

    // After appending the modifiedThoughtDiv to the error list
    const copySuggestedButton = document.querySelector('.copy-suggested-thought');
    if (copySuggestedButton) {
        copySuggestedButton.onclick = function(e) {
            e.stopPropagation();
            const textToCopy = geminiAnalysis.suggestedThought; // Ensure this variable is accessible
            navigator.clipboard.writeText(textToCopy).then(() => {
                // Show feedback
                const originalIcon = copySuggestedButton.innerHTML;
                copySuggestedButton.innerHTML = '<i class="fas fa-check"></i>'; // Change icon to checkmark
                setTimeout(() => {
                    copySuggestedButton.innerHTML = originalIcon; // Restore original icon
                }, 1500);
            });
        };
    }
}
// Expose the addTurn function to content.js
window.addTurn = addTurn;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.data) {
        const turns = request.data.turns;

        // First remove the turns that are not in the list
        for (const turnId of checkedTurnIds) {
            if (!turns.some(turn => turn.ID === turnId)) {
                const listItem = document.getElementById(turnId);
                if (listItem) {
                    listItem.remove();
                }
                checkedTurnIds = checkedTurnIds.filter(id => id !== turnId);
            }
        }
        // Set turnNumber to the current length of the error list + 1
        let turnNumber = document.getElementById('errorList').children.length + 1;

        // Process each turn sequentially
        async function processTurns() {
            for (const turn of turns) {
                // Check if the turn ID is already checked
                const isChecked = checkedTurnIds.includes(turn.ID);
                
                // If not checked, add it to the list and process it
                if (!isChecked) {
                    const analysisResults = await analyzeTurn(turn);
                    window.addTurn(turnNumber, turn, analysisResults);
                    checkedTurnIds.push(turn.ID); // Add the ID to the checked list
                    turnNumber++;
                }
            }

            // If no IDs are checked, mark all turns as checked
            if (checkedTurnIds.length === 0) {
                for (const turn of turns) {
                    checkedTurnIds.push(turn.ID); // Mark all as checked
                    const analysisResults = await analyzeTurn(turn);
                    window.addTurn(turnNumber, turn, analysisResults);
                    turnNumber++;
                }
            }
        }

        processTurns();
    }
    else if(request.IDS){
        const turns = request.IDS.turns;
        console.log(turns);
        // Remove turns that do not exist in the provided list of IDs
        turns.forEach(turn => {
            if (!checkedTurnIds.includes(turn.ID)) {
                // Find the corresponding list item and remove it
                const listItem = document.getElementById(turn.ID); // Updated to use getElementById
                if (listItem) {
                    listItem.remove(); // Remove the turn from the UI
                }
            }
        });
    }
});



async function analyzeTurn(turn) {
    // Perform regular analysis
    const regularAnalysis = performRegularAnalysis(turn);
    
    // Perform Gemini analysis
    const geminiAnalysis = await analyzeWithGemini(turn);
    
    // Combine both analyses
    return {
        ...regularAnalysis,
        geminiAnalysis
    };
}

// Move existing analysis logic to a separate function
function performRegularAnalysis(turn) {
    // analyze turns
    const WORD_MISTAKES_PATTERN = new RegExp(`\\b(?:${WORD_MISTAKES.map(word => escapeRegExp(word)).join('|')})\\b`, 'i');
    turn.analysis = {};
    // Initialize errors as an empty array if it doesn't exist
    turn.analysis.errors = []; // Ensure errors is an array
    //console.log(turn);

    const thought = turn.thought || '';
    const action = turn.action || '';
    const status = turn.metadata.status_message || '';
    // error: word mistakes
    const wordMistakeMatches = thought.match(WORD_MISTAKES_PATTERN) || [];
    if (wordMistakeMatches.length) {
        turn.analysis.errors.error_word_mistakes = wordMistakeMatches;
    }

    // error: no ends with dot
    if (!thought.trim().endsWith('.')) {
        turn.analysis.errors.error_no_ends_with_dot = true;
    }

    // error: numbers not in thought
    if (action.toLowerCase().includes("edit")) {
        const editNumbers = [...action.matchAll(/edit\s+(\d+):(\d+)/g)].map(match => match.slice(1));
        if (editNumbers.length) {
            const [first, second] = editNumbers[0];
            if (first !== '1' && second !== '1') {
                const editNumbersInThought = [first, second].every(num => thought.includes(num));
                if (!editNumbersInThought) {
                    turn.analysis.errors.error_edit_numbers_not_in_thought = true;
                }
            }
        }
    }

    // error: unmatched_backticks
    const unmatchedBackticks = (thought.match(/`/g) || []).length % 2 !== 0;
    if (unmatchedBackticks) {
        turn.analysis.errors.error_unmatched_backticks = true;
    }

    // error: camelcase words no backticks
    const camelcaseErrors = [];
    const camelcaseMatches = thought.match(CAMELCASE_PATTERN) || [];
    camelcaseMatches.forEach(camelcaseMatch => {
        if (!thought.includes(`\`${camelcaseMatch}\``)) {
            camelcaseErrors.push(camelcaseMatch);
        }
    });

    // error: uppercase words no backticks
    const uppercaseErrors = [];
    const uppercaseMatches = thought.match(UPPERCASE_PATTERN) || [];
    uppercaseMatches.forEach(uppercaseMatch => {
        if (!thought.includes(`\`${uppercaseMatch}\``)) {
            uppercaseErrors.push(uppercaseMatch);
        }
    });

    if (uppercaseErrors.length > 0) {
        turn.analysis.errors.error_uppercase_no_backticks = uppercaseErrors;
    }

    // error: common words no backticks
    const commonWordErrors = [];
    COMMON_WORDS.forEach(commonWord => {
        if (thought.includes(` ${commonWord} `) && !thought.includes(`\`${commonWord}\``)) {
            commonWordErrors.push(commonWord);
        }
    });

    if (commonWordErrors.length > 0) {
        turn.analysis.errors.error_common_word_no_backticks = commonWordErrors;
    }

    // error: snakecase words no backticks
    const snakecaseErrors = [];
    const snakecaseMatches = thought.match(SNAKECASE_PATTERN) || [];
    snakecaseMatches.forEach(snakecaseMatch => {
        const startIndex = thought.indexOf(snakecaseMatch);
        const endIndex = startIndex + snakecaseMatch.length;

        if ((endIndex < thought.length && (thought.substring(endIndex, endIndex + 3) === '.py' || thought.substring(endIndex, endIndex + 2) === '()'))) {
            return;
        }

        if ((startIndex > 0 && ['.', '('].includes(thought[startIndex - 1])) || (endIndex < thought.length && thought[endIndex] === '.')) {
            return;
        }

        if (!thought.includes(`\`${snakecaseMatch}\``)) {
            snakecaseErrors.push(snakecaseMatch);
        }
    });

    if (snakecaseErrors.length > 0) {
        turn.analysis.errors.error_snakecase_no_backticks = snakecaseErrors;
    }

    // error: path no backticks
    const pathErrors = [];
    const pathMatches = thought.match(PATH_PATTERN) || [];
    pathMatches.forEach(pathMatch => {
        if (!thought.includes(`\`${pathMatch}\``)) {
            pathErrors.push(pathMatch);
        }
    });

    if (pathErrors.length > 0) {
        turn.analysis.errors.error_path_no_backticks = pathErrors;
    }

    const misspelledWords = checkMisspelledWords(thought);
    if (misspelledWords.length > 0) {
        turn.analysis.errors.error_spell_checker = misspelledWords.map(misspelledWord => ({
            error: misspelledWord,
            correction_candidate: dictionary.suggest(misspelledWord)[0] || null
        }));
    }
    // Check if action is submit and status is not completed
    if (action.toLowerCase().includes("submit") && status.toLowerCase() !== "Submitted changes") {
        turn.analysis.errors.error_not_submit_action = true;
    }
    //console.log(turn);
    return turn;
}

// Helper function to escape regex special characters
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

let checkedTurnIds = []; // Array to store checked turn IDs


document.getElementById('copy-all-turns').onclick = function() {
    const turnTexts = Array.from(document.querySelectorAll('.turn-text')).map(turn => turn.innerText).join('\n\n');
    
    navigator.clipboard.writeText(turnTexts).then(() => {
        // Show feedback
        console.log('All turns copied to clipboard!');
        // Optionally, you can change the button text or show a notification
    }).catch(err => {
        console.error('Failed to copy: ', err);
    });
};


